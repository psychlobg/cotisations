import os,sys
from functools import partial
from datetime import datetime

__all__ = ['perror']

###A remplacer par logger
perror = partial(print, file=sys.stderr)

