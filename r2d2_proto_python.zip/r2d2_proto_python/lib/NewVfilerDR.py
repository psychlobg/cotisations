import os,sys
from  .SevenModeApi import SevenModeApi
import logging


class NewVfilerDR(SevenModeApi):
    """ Class de création des Vfilers. Hérite de l'objet FilerAPI.
        vfiler_properties["filer"]=filer_primaire
        vfiler_properties["vfiler"]=vfiler_name
        vfiler_properties["aggregat"]=aggr_primaire
        vfiler_properties["ip_info"]=[{"interface":if,"ip-address":ip,"netmask";netmask},...]
        vfiler_properties["dns"]=["ip1","ip2",..]
        vfiler_properties["remote_vfiler_location"]={"filer":filer-source,"vfiler": vfiler-source}
        vfiler_properties["remote_authentification"]={"username":user,"password":password}
    """
    CREATEKEYS=("filer","vfiler","ip_info","dns","remote_vfiler_location","remote_authentification")


    def __init__(self, properties, user,password):
        self.properties=properties
        self.checkValues()
        self.filer=properties["filer"]
        super().__init__(self.filer,user,password)
        self.vfilername=properties["vfiler"]
        self.log=None
        self.volume_root_name=None
        return

    def get_vfilername(self):
        return self.vfilername

    def checkValues(self):
        for k in self.CREATEKEYS:
            if k in self.properties.keys():
                if self.properties[k] is None: raise Exception("NewVfilerDR Error","La valeur de la cle %s est nulle"%(k))
            else:
                raise Exception("NewVfilerDR Error","Cle %s manquante"%(k))
        return

    def setProperties(self, properties):
        """
        :param properties: dictionnaire de propriétés.
                vfiler_properties["filer"]=filer_primaire
                vfiler_properties["vfiler"]=vfiler_name
                vfiler_properties["aggregat"]=aggr_primaire
                vfiler_properties["ip_info"]=[{"interface":if,"ip-address":ip,"netmask";netmask},...]
                vfiler_properties["dns"]=["ip1","ip2",..]
	            vfiler_properties["remote_vfiler_location"]={"filer":filer-source,"vfiler": vfiler-source}
	            vfiler_properties["remote_authentification"]={"username":user,"password":password}
        :return: Exception
        """
        self.properties=properties
        self.checkValues()
        return

    def connect(self):
        """
            Connexion au filer pour valider la liason
        :return:
        """
        version=self.get_version()
        if self.log: self.log.debug(version)
        return version

    def createVolumeRoot(self, rules):
        """
            Création du volume root
        :param size:
        :param rules:
        :return:
        """

        #Creation du volume
        self.volume_create(self.volume_root_name, self.properties["aggregat"], rules.getDefaultSize())
        # setting des options
        self.volume_setoptions(self.volume_root_name, rules.getVolOptions())
        #snapshot reserve
        self.volume_setsnapshot_reserve(self.volume_root_name, rules.getSnapReserve())
        #snashot sched
        self.volume_setsnapshot_sched(self.volume_root_name, rules.getSnapSched())
        #sdeduplication
        self.volume_set_sis(self.volume_root_name, rules.getSisStatus())
        self.volume_sis_sched(self.volume_root_name, rules.getSisSched())

        return


    def createVfilerDR(self, rules):
        """
            Creation du vfiler, les properties doivent avoir été définies
        :param rules: regle definissant le paramètrage des volumes
        :param default_password : mot de passe par defaut
        :return:
        """
        if self.properties is None: raise Exception("NewVfilerDR Error","Create : properties non definis")
                #definition du nom
        self.volume_root_name=rules.makeVolName(self.get_vfilername())
        #creation du volume
        self.createVolumeRoot(rules)

        # vfiler_properties["filer"]=filer_primaire
        # vfiler_properties["vfiler"]=vfiler_name
        # vfiler_properties["aggregat"]=aggr_primaire
        # vfiler_properties["ip_info"]=[{"interface":if,"ip-address":ip,"netmask";netmask},...]
        # vfiler_properties["dns"]=["ip1","ip2",..]
	    # vfiler_properties["remote_vfiler_location"]={"filer":filer-source,"vfiler": vfiler-source}
	    # vfiler_properties["remote_authentification"]={"username":user,"password":password}
        # :param adIpaddrs_info: tableau de dictionnaire
        #         adIpaddrs_info=[{"interface":if,"ip-address":ip,"netmask";netmask},...]
        # :param aIpdns: tableau avec la liste de dns aIpdns=["ip1","ip2",..]
        # :param dRemote_authent_info: dRemote_authent_info={"username":user,"password":password}
        # :param dRemote_vfiler_location: dRemote_vfiler_location ={"filer":filer-source,"vfiler": vfiler-source}

        self.vfiler_drconfigure(self.properties["ip_info"], self.properties["dns"],
                                self.properties["remote_authentification"],
                                self.properties["remote_vfiler_location"])

        return




