# -*- coding: utf-8 -*-
from sqlalchemy import Column
from sqlalchemy.types import Unicode, Integer, DateTime, String
from sqlalchemy import desc
from sqlalchemy.sql import func

from lib.db import Base

__all__ = ['RefFilerTable','RefCampusTable', 'RefDomainTable', 'RefPoolIpTable']

class RefFilerTable(Base):
    """ Table FILER pour la base de données référentiel. S'appuie sur SQLAlchemy.
    """
    __tablename__ = 'filer'
    # name;ip;site;client;environment;application (BUR ou AUTRE);police_gold;police_silver;police_Bronze

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(128), nullable=False)
    ip = Column(String(32), nullable=False)
    site = Column(String(32), nullable=False)
    client = Column(String(32), nullable=False)
    environment = Column(String(32), nullable=False)
    application = Column(String(32), nullable=False)
    police_platine = Column(String(32), nullable=False)
    police_gold = Column(String(32), nullable=False)
    police_silver = Column(String(32), nullable=False)
    police_bronze = Column(String(32), nullable=False)

class RefDomainTable(Base):
    """ Table DOMAIN pour la base de données référentiel. S'appuie sur SQLAlchemy.
    """
    __tablename__ = 'domain'
    # name;ip;site;client;environment;application (BUR ou AUTRE);police_gold;police_silver;police_Bronze

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(128), nullable=False)
    campus = Column(String(32), nullable=False)
    client = Column(String(32), nullable=False)
    environment = Column(String(32), nullable=False)
    dns = Column(String(256), nullable=False)
    user = Column(String(32), nullable=False)
    password = Column(String(64), nullable=False)

class RefCampusTable(Base):
    """ Table FILER pour la base de données référentiel. S'appuie sur SQLAlchemy.
    """
    __tablename__ = 'campus'
    # name;ip;site;client;environment;application (BUR ou AUTRE);police_gold;police_silver;police_Bronze

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(128), nullable=False)
    site = Column(String(512), nullable=False)

class RefPoolIpTable(Base):
    """ Table FILER pour la base de données référentiel. S'appuie sur SQLAlchemy.
    """
    __tablename__ = 'pool_ip'
    # name;ip;site;client;environment;application (BUR ou AUTRE);police_gold;police_silver;police_Bronze

    # id = Column(Integer, primary_key=True, autoincrement=True)
    ip = Column(String(512), nullable=False, primary_key=True, unique=True)
    netmask = Column(String(128), nullable=False)
    gateway = Column(String(128), nullable=False)
    vlan = Column(String(128), nullable=False)
    campus = Column(String(128), nullable=False)
    vfiler = Column(String(128), nullable=True)