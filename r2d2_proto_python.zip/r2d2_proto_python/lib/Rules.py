


class Rules(object):
    """ Classe abstraite. la méthode makeVolName n'est pas implémenté
    """
    TYPES=()
    KEYWORDS=()

    def __init__(self, typeVol, rules):

        self.rules=rules[typeVol]
        self.typeVol=typeVol
        if typeVol not in self.TYPES: raise Exception("Rules Error", "Type %s inconnu" % (typeVol))

    def makeVolName(self,typeVol):
        raise Exception("Rules Error","makeVolName n est pas implementé")
        return
    def getDefaultSize(self):
        return self.rules["size"]

    def getVolOptions(self):
        return self.rules["options"]

    def getSnapSched(self):
        return self.rules["snapshot"]

    def getSnapReserve(self):
        return self.rules["snapshot-reserve"]

    def getSisStatus(self):
        return self.rules["sis-status"]

    def getSisSched(self):
        return self.rules["sis-sched"]


class RuleItce(Rules):
    TYPES=("ROOT","NAS","OSSV","BUR")
    def __init__(self, typeVol, rules):
        super().__init__(typeVol, rules)

    def makeVolName(self,vfiler,name=None):
        volname=self.rules["name"].replace("<VFILER>",vfiler)
        volname=volname.replace("<NAME>","root")
        return volname

class RuleEQX(Rules):
    TYPES=("ROOT","NAS","BUR")

    def __init__(self, typeVol, rules, application):
        super().__init__(typeVol, rules)
        self.application = application

    def makeVolName(self,vfiler):
        volname=self.rules["name"].replace("<VFILER>",vfiler)
        volname=volname.replace("<APP>",self.application)
        return volname
