#!/opt/UNS/VENV/VENV_CISCO/bin/python3
# -*- coding: utf-8 -*-
# Alimentation de la database

import os
import sys
import context
from datetime import datetime
###A remplacer par logger
from lib.utils.utils import perror

from config import Config

if __name__ == '__main__':
    myconfig = Config(os.path.abspath('..'))
    from lib.db.Inventaire import Inventaire

    from lib.SevenModeApi import SevenModeApi, NaError

    inventaire=Inventaire(myconfig.database_inventory)
    inventaire.flush()
    from lib.db.Referentiel import Referentiel
    ref = Referentiel(myconfig.referentiel_inventory)
    filers=ref.listAllFiler()
    listeFilers=[u["name"] for u in filers]
    print(listeFilers)
    d = datetime.now()
    print( ("Debut %.2d:%.2d")%(d.hour,d.minute) )
    for fas in listeFilers:
        try:
            print(fas)
            myFiler=SevenModeApi(fas, myconfig.batch_user, myconfig.batch_passwd)
            vDict={}
            dictVol={}
            dicAggr={}
            vDict=myFiler.vfiler_list_info()
            dictVol=myFiler.volume_listinfo()
            dicAggr=myFiler.aggr_spaceinfo()
            tabIpspace=myFiler.ipspace_list_info()
            for k in dicAggr.keys():
                print("Aggregat",k)
                dicAggr[k]["typeDisk"]=myFiler.aggr_get_disk_type(k)
                #print(k,dicAggr[k]["typeDisk"])

            myFiler=None
        except NaError as e:
            d = datetime.now()
            perror(("%.2d%.2d-%.2d%.2d: [errno %s]= %s from %s")%(d.day,d.month,d.hour,d.minute,e.errno,e.message,e.function))
            #
        for k in vDict.keys():
            inventaire.addVfiler(vDict[k]["name"],vDict[k]["status"],fas, vDict[k]["ip"],vDict[k]["ipspace"])

        for k in dictVol.keys():
            inventaire.addVolume(k,dictVol[k]["state"], dictVol[k]["owningVfiler"], fas,
                                 dictVol[k]["sizeTotal"], dictVol[k]["sizeUsed"],
                                 dictVol[k]["snapReserve"], dictVol[k]["containing-aggregate"]
                                 )
        for k in dicAggr.keys():
            inventaire.addAggregat(k, fas, dicAggr[k]["aggrSizeNominal"],
                                   dicAggr[k]["aggrSizeUsed"],
                                   dicAggr[k]["volProvisionning"],
                                   dicAggr[k]["typeDisk"])

        for t in tabIpspace:
            inventaire.addInterface(name=t[1],ipspace=t[0],filer=fas,vlan=t[2])

    d = datetime.now()
    print( ("Fin %.2d:%.2d")%(d.hour,d.minute) )
