#!/opt/UNS/VENV/VENV_CISCO/bin/python3
# -*- coding: utf-8 -*-
# Creation de la database
#! /usr/bin/python3

import os
import sys
import context
from config import Config

if __name__ == '__main__':
    myconfig = Config(os.path.abspath('..'))
    print(myconfig.base_dir)
    from lib.db import Base,create_engine
    from lib.db.TablesReferentiel import RefFilerTable

    engine = create_engine('sqlite:///' + myconfig.referentiel_inventory)
    # Create all tables in the engine. This is equivalent to "Create Table"
    # statements in raw SQL.
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
