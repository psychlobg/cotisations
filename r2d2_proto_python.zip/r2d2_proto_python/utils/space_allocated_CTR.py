#!/opt/UNS/VENV/VENV_CISCO/bin/python3
# -*- coding: utf-8 -*-
# Alimentation de la database
from __future__ import print_function
import os
import sys
import context
from datetime import datetime
###A remplacer par logger
from lib.utils.utils import perror
from lib.AppLogger import AppLogger

from config import Config
import argparse

def commandline_parser():
    p = argparse.ArgumentParser(description=os.path.basename( sys.argv[0] ))
    p.add_argument('-n','--nom',  type=str, help="Nom du filer",required=True)
    args=p.parse_args()
    return args

if __name__ == '__main__':
    myconfig = Config(os.path.abspath('..'))
    myLog=AppLogger(os.path.basename(__file__),myconfig.log)
    from lib.db.Inventaire import Inventaire
    from lib.SevenModeApi import SevenModeApi, NaError
    inventaire=Inventaire(myconfig.database_inventory)
    #args=commandline_parser()
    #fas=args.nom.upper()

    d = datetime.now()
  #  myLog.info( ("Debut %.2d:%.2d")%(d.hour,d.minute) )
    FAS=["NASTOE01","NCSTOE01","MCSTOE01","RESTOE01","RISTOE01","VFSTOE01"]
    #FAS=["NASTOE01"]
    keys=['sizeTotal','snapReserve','sizeUsed','state','is-snapmirror-destination','is-snapmirror-source','owningVfiler']
    print('controller',end=';')
    print('volume',end=';')
    for i in keys:
       print(i,end=';')  
    print(" ", flush= True)
    try:
        for fas in FAS:
        #myFiler=SevenModeApi(fas, myconfig.batch_user, myconfig.batch_passwd)
           myFiler=SevenModeApi(fas, "root", "VU3*3UA=7")
           vDict={}
           dictVol={}
           dicAggr={}
        #      myLog.info("Recuperation infos volumes")
           dictVol=myFiler.volume_listinfo()
           for vol,data in dictVol.items():
              print(fas,end=';')
              print(vol,end=';')
              for i in keys:
                 print(data[i],end=';')
              print(" ", flush= True)
    except NaError as e:
        d = datetime.now()
        perror(("%.2d%.2d-%.2d%.2d: [errno %s]= %s from %s")%(d.day,d.month,d.hour,d.minute,e.errno,e.message,e.function))
        exit()
    except Exception as e:
        d = datetime.now()
        perror(("%.2d%.2d-%.2d%.2d: [errno %s]")%(d.day,d.month,d.hour,d.minute,e.message))
        exit()
