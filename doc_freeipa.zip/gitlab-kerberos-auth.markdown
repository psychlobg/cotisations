# Configuration de l'authentification Kerberos pour GitLab EE avec Active Directory

Ce document décrit la configuration de l'authentification **Kerberos** pour un serveur **GitLab Enterprise Edition (EE)** local, permettant le **Single Sign-On (SSO)** avec Active Directory (AD). Il inclut une étape pour vérifier si **Nginx** ou **Apache** est utilisé comme serveur web, les étapes pour configurer le serveur GitLab, les clients Windows et Linux, et ajouter le site (`gitlab.example.com`) aux sites de confiance dans Firefox et Chrome sur Windows. Des tests avec `curl` sont également fournis pour vérifier l'accès. Cette configuration suppose que l'authentification LDAP est déjà en place comme fallback.

## Hypothèses
- Domaine AD : `EXAMPLE.COM`
- FQDN du serveur GitLab : `gitlab.example.com`
- GitLab EE est configuré avec HTTPS (certificat SSL valide).
- LDAP est déjà configuré pour AD et reste disponible comme fallback.
- Clients : Windows (joints au domaine) et Linux (avec Kerberos configuré).

## Prérequis
- **GitLab EE** : Version installée localement (Kerberos est uniquement disponible dans EE).
- **AD** :
  - Droits pour créer un compte de service et un keytab.
  - Accès au contrôleur de domaine (ex. : `dc.example.com`).
- **DNS** : `gitlab.example.com` doit être résolu correctement dans AD.
- **Paquets** :
  - Sur le serveur Linux : `krb5-user` pour Kerberos.
  - Nginx (utilisé par défaut avec GitLab) : `ngx_http_auth_spnego_module` (peut nécessiter compilation).
  - Apache (si utilisé) : `libapache2-mod-auth-kerb`.
  - `curl` avec support Kerberos (`libcurl4-gnutls-dev` ou `libcurl4-openssl-dev` sur Linux).
- **Certificat SSL** : Nécessaire pour HTTPS.
- **Clients** :
  - Windows : Machines jointes au domaine.
  - Linux : Configurées avec `/etc/krb5.conf` et tickets Kerberos.

## 1. Configuration du serveur GitLab

### 1.1 Vérifier si Nginx ou Apache est utilisé
1. **Vérifier les processus en cours d’exécution** :
   - Exécutez la commande suivante pour voir si Nginx ou Apache est actif :
     ```bash
     ps aux | grep -E 'nginx|apache|httpd'
     ```
     - Si vous voyez des processus comme `nginx: master process` ou `nginx: worker process`, GitLab utilise **Nginx** (par défaut).
     - Si vous voyez des processus comme `apache2` ou `httpd`, **Apache** est utilisé.

2. **Vérifier les services système** :
   - Pour Nginx :
     ```bash
     systemctl status nginx
     ```
     - Si le service est actif, Nginx est utilisé.
   - Pour Apache :
     ```bash
     systemctl status apache2
     ```
     - Si le service est actif, Apache est utilisé.

3. **Vérifier la configuration GitLab** :
   - Consultez `/etc/gitlab/gitlab.rb` pour voir si Nginx est activé :
     ```bash
     grep nginx['enable'] /etc/gitlab/gitlab.rb
     ```
     - Si `nginx['enable'] = true` (par défaut), GitLab utilise Nginx.
     - Si `nginx['enable'] = false` et Apache est configuré (par exemple, via `external_webserver`), Apache est utilisé.
   - Vérifiez la présence de fichiers de configuration :
     - Nginx : `/var/opt/gitlab/nginx/conf/gitlab-http.conf` (généré par GitLab).
     - Apache : `/etc/apache2/sites-available/gitlab.conf` (si configuré manuellement).

4. **Vérifier les ports** :
   - Vérifiez quel serveur écoute sur le port 80 ou 443 :
     ```bash
     netstat -tulnp | grep -E ':80|:443'
     ```
     - Si `nginx` écoute, c’est Nginx.
     - Si `apache2` ou `httpd` écoute, c’est Apache.

5. **Conclusion** :
   - Par défaut, GitLab EE utilise **Nginx**. Si vous avez configuré Apache manuellement, suivez les étapes Apache ci-dessous.

### 1.2 Créer un compte de service et un keytab dans AD
1. **Créer un compte de service** :
   - Sur le contrôleur de domaine (Windows) :
     ```powershell
     New-ADUser -Name "HTTP_gitlab" -UserPrincipalName "HTTP/gitlab.example.com@EXAMPLE.COM" -AccountPassword (ConvertTo-SecureString "P@ssw0rd" -AsPlainText -Force) -Enabled $true
     setspn -A HTTP/gitlab.example.com@EXAMPLE.COM HTTP_gitlab
     ```

2. **Générer un keytab** :
   ```powershell
   ktpass -princ HTTP/gitlab.example.com@EXAMPLE.COM -mapuser HTTP_gitlab@EXAMPLE.COM -crypto ALL -ptype KRB5_NT_PRINCIPAL -pass P@ssw0rd -out gitlab.keytab
   ```
   - Transférez `gitlab.keytab` sur le serveur Linux (par exemple, via SCP).

3. **Installer le keytab** :
   ```bash
   mv gitlab.keytab /etc/gitlab/gitlab.keytab
   chmod 600 /etc/gitlab/gitlab.keytab
   chown gitlab:gitlab /etc/gitlab/gitlab.keytab
   ```

### 1.3 Configurer Kerberos sur le serveur Linux
1. **Installer les outils Kerberos** :
   ```bash
   apt-get install krb5-user
   ```

2. **Configurer `/etc/krb5.conf`** :
   ```ini
   [libdefaults]
       default_realm = EXAMPLE.COM
       dns_lookup_realm = false
       dns_lookup_kdc = false

   [realms]
       EXAMPLE.COM = {
           kdc = dc.example.com
           admin_server = dc.example.com
       }

   [domain_realm]
       .example.com = EXAMPLE.COM
       example.com = EXAMPLE.COM
   ```

3. **Tester le keytab** :
   ```bash
   kinit -k -t /etc/gitlab/gitlab.keytab HTTP/gitlab.example.com@EXAMPLE.COM
   klist
   ```
   - Vérifiez qu’un ticket est affiché.

### 1.4 Configurer GitLab pour Kerberos
1. **Activer Kerberos dans GitLab** :
   - Modifiez `/etc/gitlab/gitlab.rb` pour activer OmniAuth avec Kerberos :
     ```ruby
     gitlab_rails['omniauth_enabled'] = true
     gitlab_rails['omniauth_allow_single_sign_on'] = ['kerberos']
     gitlab_rails['omniauth_providers'] = [
       {
         name: 'kerberos',
         label: 'Kerberos SSO'
       }
     ]
     ```
   - **Note** : Votre configuration LDAP existante (déjà présente dans `gitlab_rails['ldap_servers']`) reste intacte comme fallback.

2. **Configurer Nginx pour Kerberos (si utilisé)** :
   - Installez le module Kerberos pour Nginx :
     ```bash
     apt-get install libkrb5-dev
     ```
     - Compilez `ngx_http_auth_spnego_module` si nécessaire (ou utilisez un dépôt tiers comme GetPageSpeed).
   - Modifiez la configuration Nginx générée par GitLab :
     - Créez ou modifiez `/var/opt/gitlab/nginx/conf/gitlab-http.conf` (ou intégrez dans un fichier inclus) :
       ```nginx
       server {
           listen 443 ssl;
           server_name gitlab.example.com;

           ssl_certificate /path/to/cert.pem;
           ssl_certificate_key /path/to/key.pem;

           location / {
               auth_gss on;
               auth_gss_keytab /etc/gitlab/gitlab.keytab;
               auth_gss_service_name HTTP/gitlab.example.com@EXAMPLE.COM;
               auth_gss_realm EXAMPLE.COM;

               proxy_pass http://localhost:8080; # Port interne de GitLab
               proxy_set_header Host $host;
               proxy_set_header X-Real-IP $remote_addr;
               proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
               proxy_set_header X-Forwarded-Proto $scheme;
           }
       }
       ```
   - Incluez ce fichier dans `/etc/nginx/nginx.conf` si nécessaire :
     ```nginx
     include /var/opt/gitlab/nginx/conf/gitlab-http.conf;
     ```

3. **Configurer Apache pour Kerberos (si utilisé)** :
   - Installez le module Kerberos :
     ```bash
     apt-get install libapache2-mod-auth-kerb
     a2enmod auth_kerb
     ```
   - Créez ou modifiez `/etc/apache2/sites-available/gitlab.conf` :
     ```apache
     <VirtualHost *:443>
         ServerName gitlab.example.com
         DocumentRoot /opt/gitlab/embedded/service/gitlab-rails/public

         SSLEngine on
         SSLCertificateFile /path/to/cert.pem
         SSLCertificateKeyFile /path/to/key.pem

         <Directory /opt/gitlab/embedded/service/gitlab-rails/public>
             AuthType Kerberos
             AuthName "Kerberos or LDAP Login"
             KrbMethodNegotiate On
             KrbMethodK5Passwd Off
             KrbServiceName HTTP
             KrbAuthRealms EXAMPLE.COM
             Krb5KeyTab /etc/gitlab/gitlab.keytab
             Require valid-user

             ProxyPass http://localhost:8080/
             ProxyPassReverse http://localhost:8080/
         </Directory>
     </VirtualHost>
     ```
   - Activez le site :
     ```bash
     a2ensite gitlab
     ```

4. **Reconfigurer GitLab** :
   ```bash
   gitlab-ctl reconfigure
   ```

5. **Redémarrer Nginx ou Apache** :
   ```bash
   systemctl restart nginx  # ou apache2
   ```

## 2. Configuration des clients

### 2.1 Clients Windows

#### Firefox : Ajouter aux sites de confiance
1. **Ouvrir les paramètres avancés** :
   - Lancez Firefox.
   - Tapez `about:config` dans la barre d’adresse.
   - Cliquez sur **Accepter le risque et continuer**.

2. **Configurer les URI de confiance** :
   - Recherchez :
     ```
     network.negotiate-auth.trusted-uris
     ```
   - Double-cliquez et ajoutez :
     ```
     gitlab.example.com
     ```
   - Pour plusieurs serveurs : `gitlab.example.com,otherserver.example.com`.

3. **(Facultatif) Configurer la délégation** :
   - Si nécessaire :
     ```
     network.negotiate-auth.delegation-uris
     ```
     - Ajoutez : `gitlab.example.com`.

4. **Vérifier les tickets Kerberos** :
   - Assurez-vous que la machine est jointe au domaine :
     ```powershell
     systeminfo | findstr /B /C:"Domain"
     ```
   - Vérifiez les tickets :
     ```cmd
     klist
     ```

#### Chrome : Ajouter aux sites de confiance
1. **Ajouter à la zone Intranet local/Sites de confiance** :
   - Ouvrez **Panneau de configuration** > **Options Internet**.
   - Allez dans **Sécurité** > **Intranet local** ou **Sites de confiance** > **Sites**.
   - Ajoutez : `https://gitlab.example.com`.
   - Décochez **Exiger une vérification du serveur (https:)** si vous testez en HTTP (non recommandé).

2. **(Alternative) Configurer via GPO** :
   - Ouvrez `gpedit.msc` ou utilisez un GPO AD.
   - Naviguez vers :
     ```
     Configuration utilisateur > Stratégies > Modèles d'administration > Google > Google Chrome
     ```
   - Activez **Liste des URL de l’authentification intégrée** :
     - Ajoutez : `gitlab.example.com`.
   - (Facultatif) Activez **Liste des URL pour la délégation d’identifiants Kerberos** :
     - Ajoutez : `gitlab.example.com`.

3. **(Alternative) Configurer via le registre** :
   ```powershell
   Set-ItemProperty -Path "HKLM:\Software\Policies\Google\Chrome\AuthServerWhitelist" -Name "AuthServerWhitelist" -Value "gitlab.example.com"
   Set-ItemProperty -Path "HKLM:\Software\Policies\Google\Chrome\AuthNegotiateDelegateWhitelist" -Name "AuthNegotiateDelegateWhitelist" -Value "gitlab.example.com"
   ```

4. **Vérifier les tickets Kerberos** :
   ```cmd
   klist
   ```

#### Edge (pour complétude)
- Suivez les mêmes étapes que pour Chrome (Options Internet, GPO, ou registre).

### 2.2 Clients Linux
1. **Configurer Kerberos** :
   - Installez les outils :
     ```bash
     apt-get install krb5-user
     ```
   - Configurez `/etc/krb5.conf` (voir section 1.3).
   - Obtenez un ticket :
     ```bash
     kinit username@EXAMPLE.COM
     klist
     ```

2. **Configurer Firefox** :
   - Ajoutez `gitlab.example.com` à `network.negotiate-auth.trusted-uris` dans `about:config`.

3. **Configurer Chrome** :
   - Lancez avec :
     ```bash
     google-chrome --auth-server-whitelist="gitlab.example.com" --auth-negotiate-delegate-whitelist="gitlab.example.com"
     ```

4. **(Facultatif) Joindre le domaine** :
   ```bash
   apt-get install realmd sssd krb5-user
   realm join EXAMPLE.COM -U administrator
   ```
   - Configurez `/etc/sssd/sssd.conf` :
     ```ini
     [sssd]
     domains = EXAMPLE.COM
     services = nss, pam

     [domain/EXAMPLE.COM]
     id_provider = ad
     auth_provider = ad
     krb5_realm = EXAMPLE.COM
     ```
   - Redémarrez SSSD :
     ```bash
     systemctl restart sssd
     ```

## 3. Tests avec `curl`

### Tester l’authentification Kerberos
1. **Sur Linux** :
   - Configurez `/etc/krb5.conf` (voir section 1.3).
   - Obtenez un ticket Kerberos :
     ```bash
     kinit username@EXAMPLE.COM
     klist
     ```
   - Testez avec `curl` :
     ```bash
     curl --negotiate -u : https://gitlab.example.com
     ```
     - Si erreur SSL (certificat auto-signé) :
       ```bash
       curl --negotiate -u : -k https://gitlab.example.com
       ```

2. **Sur Windows** :
   - Vérifiez que la machine est jointe au domaine :
     ```powershell
     systeminfo | findstr /B /C:"Domain"
     ```
   - Vérifiez les tickets :
     ```cmd
     klist
     ```
   - Testez avec `curl` :
     ```powershell
     curl --negotiate -u : https://gitlab.example.com
     ```
     - Si erreur SSL :
       ```powershell
       curl --negotiate -u : -k https://gitlab.example.com
       ```

3. **Résultat attendu** :
   - Si réussi, `curl` affiche la page de connexion GitLab ou une redirection (code HTML).
   - Si erreur 401 (Unauthorized), vérifiez le ticket Kerberos, la configuration du serveur, ou les logs.

### Tester l’authentification LDAP (fallback)
- Si Kerberos échoue, GitLab redirige vers l’interface de connexion LDAP.
- Testez avec `curl` en utilisant vos identifiants LDAP existants :
  ```bash
  curl -u username@EXAMPLE.COM:password https://gitlab.example.com
  ```
  - Si erreur SSL :
    ```bash
    curl -u username@EXAMPLE.COM:password -k https://gitlab.example.com
    ```
- **Résultat attendu** :
  - Si réussi, `curl` affiche la page de connexion ou une redirection.
  - Si erreur 401, vérifiez les identifiants ou la configuration LDAP dans `/etc/gitlab/gitlab.rb`.

## 4. Dépannage
- **Kerberos échoue** :
  - Vérifiez le keytab : `kinit -k -t /etc/gitlab/gitlab.keytab HTTP/gitlab.example.com@EXAMPLE.COM`.
  - Vérifiez `/etc/krb5.conf`.
  - Assurez-vous que `gitlab.example.com` est résolu (DNS) :
    ```bash
    nslookup gitlab.example.com
    ```
  - Vérifiez les tickets : `klist` (Windows) or `klist` après `kinit` (Linux).
  - Consultez les logs GitLab : `/var/log/gitlab/nginx/gitlab_access.log` ou `/var/log/apache2/gitlab_access.log`.
- **Authentification LDAP échoue** :
  - Vérifiez la configuration LDAP dans `/etc/gitlab/gitlab.rb`.
  - Vérifiez les identifiants (`username@EXAMPLE.COM` ou `EXAMPLE\username`).
  - Consultez les logs : `/var/log/gitlab/gitlab-rails/production.log`.
- **Erreur SSL avec `curl`** :
  - Utilisez `-k` pour les tests, mais configurez un certificat SSL valide pour la production.
- **Navigateur** :
  - Confirmez que `gitlab.example.com` est dans les sites de confiance.
  - Vérifiez la synchronisation de l’heure (Kerberos est sensible aux décalages).

## 5. Remarques
- **HTTPS** : Obligatoire pour sécuriser les échanges Kerberos et LDAP.
- **Kerberos prioritaire** : GitLab tente Kerberos en premier, puis redirige vers LDAP si Kerberos échoue.
- **LDAP existant** : La configuration LDAP reste inchangée et sert de fallback.
- **Nginx par défaut** : GitLab utilise Nginx par défaut. Si Apache est utilisé, il doit être configuré manuellement.
- **Documentation** : Consultez la documentation GitLab pour [OmniAuth Kerberos](https://docs.gitlab.com/ee/integration/kerberos.html).