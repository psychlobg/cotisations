### Variables FreeIPA et NetApp
```yaml
# inventories/production/group_vars/freeipa.yml
freeipa_server: "ipa.{{ domain }}"
keytab_temp_dir: "/tmp/ansible-keytabs"

# inventories/production/group_vars/netapp.yml
netapp_ontap:
  hostname: "{{ netapp_cluster }}"
  username: "{{ netapp_username }}"
  password: "{{ netapp_password }}"
  validate_certs: false
  
# SVM configurations
svm_configs:
  - name: "svm01"
    lif_name: "nfs_data_lif"
    freeipa_ip: "192.168.1.10"
  - name: "svm02"
    lif_name: "nfs_data_lif2"
    freeipa_ip: "192.168.1.10"
```

### Rôle de génération keytab avec S3 ONTAP
```yaml
# roles/keytab-s3-ontap/tasks/main.yml
---
- name: Create temporary keytab directory
  file:
    path: "{{ keytab_temp_dir }}"
    state: directory
    mode: '0700'

- name: Generate keytab for SVM
  command: >
    ipa-getkeytab 
    -s {{ freeipa_server }}
    -p nfs/{{ svm_name }}.{{ domain }}
    -k {{ keytab_temp_dir }}/{{ svm_name }}_{{ ansible_date_time.epoch }}.keytab
  register: keytab_generation
  
- name: Add host principal to keytab
  command: >
    ipa-getkeytab 
    -s {{ freeipa_server }}
    -p host/{{ svm_name }}.{{ domain }}
    -k {{ keytab_temp_dir }}/{{ svm_name }}_{{ ansible_date_time.epoch }}.keytab
  register: host_principal_add

- name: Verify keytab content
  command: klist -k {{ keytab_temp_dir }}/{{ svm_name }}_{{ ansible_date_time.epoch }}.keytab
  register: keytab_content

- name: Display keytab content
  debug:
    msg: "{{ keytab_content.stdout_lines }}"

- name: Configure AWS CLI for ONTAP S3
  command: aws configure set {{ item.key }} {{ item.value }}
  loop:
    - { key: "aws_access_key_id", value: "{{ ontap_s3_access_key }}" }
    - { key: "aws_secret_access_key", value: "{{ ontap_s3_secret_key }}" }
    - { key: "default.region", value: "{{ s3_region }}" }
    - { key: "default.output", value: "json" }
  no_log: true

- name: Upload keytab to ONTAP S3
  command: >
    aws s3 cp {{ keytab_temp_dir }}/{{ svm_name }}_{{ ansible_date_time.epoch }}.keytab
    s3://{{ s3_bucket }}/keytabs/{{ svm_name }}_{{ ansible_date_time.epoch }}_{{ ansible_hostname }}.keytab
    --endpoint-url {{ s3_endpoint }}
    --metadata "svm={{ svm_name }},domain={{ domain }},generated={{ ansible_date_time.iso8601 }},cluster={{ ansible_hostname }}"
  register: s3_upload

- name: Generate presigned URL
  command: >
    aws s3 presign 
    s3://{{ s3_bucket }}/keytabs/{{ svm_name }}_{{ ansible_date_time.epoch }}_{{ ansible_hostname }}.keytab
    --endpoint-url {{ s3_endpoint }}
    --expires-in {{ keytab_expiry_hours * 3600 }}
  register: presigned_url_generation

- name: Set presigned URL fact
  set_fact:
    keytab_presigned_url: "{{ presigned_url_generation.stdout }}"
    s3_key: "keytabs/{{ svm_name }}_{{ ansible_date_time.epoch }}_{{ ansible_hostname }}.keytab"

- name: Display presigned URL info
  debug:
    msg: |
      S3 Key: {{ s3_key }}
      Presigned URL: {{ keytab_presigned_url }}
      Expires in: {{ keytab_expiry_hours }} hours
      Expires at: {{ (ansible_date_time.epoch | int + keytab_expiry_hours * 3600) | strftime('%Y-%m-%d %H:%M:%S') }}

- name: Test presigned URL accessibility
  uri:
    url: "{{ keytab_presigned_url }}"
    method: HEAD
    status_code: 200
  register: url_test

- name: Clean up local keytab
  file:
    path: "{{ keytab_temp_dir }}/{{ svm_name }}_{{ ansible_date_time.epoch }}.keytab"
    state: absent
```

### Rôle de configuration NetApp Kerberos
```yaml
# roles/netapp-kerberos-ontap/tasks/main.yml
---
- name: Configure Kerberos realm on NetApp
  netapp.ontap.na_ontap_nfs_kerberos_config:
    state: present
    vserver: "{{ svm_name }}"
    kdc_ip: "{{ freeipa_ip }}"
    kdc_port: 88
    kdc_vendor: "Other"
    admin_server_ip: "{{ freeipa_ip }}"
    admin_server_port: 749
    default_realm: "{{ realm }}"
    clock_skew: 5
    hostname: "{{ netapp_ontap.hostname }}"
    username: "{{ netapp_ontap.username }}"
    password: "{{ netapp_ontap.password }}"
    validate_certs: "{{ netapp_ontap.validate_certs }}"

- name: Enable Kerberos on NFS interface with S3 keytab
  netapp.ontap.na_ontap_nfs_kerberos_interface:
    state: present
    vserver: "{{ svm_name }}"
    interface_name: "{{ lif_name }}"
    spn: "nfs/{{ svm_name }}.{{ domain }}@{{ realm }}"
    keytab_uri: "{{ keytab_presigned_url }}"
    hostname: "{{ netapp_ontap.hostname }}"
    username: "{{ netapp_ontap.username }}"
    password: "{{ netapp_ontap.password }}"
    validate_certs: "{{ netapp_ontap.validate_certs }}"
  register: kerberos_interface_result

- name: Display Kerberos interface result
  debug:
    msg: "Kerberos interface configured successfully for {{ svm_name }}"
  when: kerberos_interface_result is succeeded

- name: Verify Kerberos configuration
  netapp.ontap.na_ontap_info:
    gather_subset: "nfs_kerberos_interface_info"
    vserver: "{{ svm_name }}"
    hostname: "{{ netapp_ontap.hostname }}"
    username: "{{ netapp_ontap.username }}"
    password: "{{ netapp_ontap.password }}"
    validate_certs: "{{ netapp_ontap.validate_certs }}"
  register: kerberos_verification

- name: Display Kerberos verification
  debug:
    var: kerberos_verification.ontap_info.nfs_kerberos_interface_info
```

### Playbook principal
```yaml
# playbooks/deploy-kerberos-ontap-s3.yml
---
- name: Deploy NetApp Kerberos with ONTAP S3 keytab storage
  hosts: localhost
  gather_facts: true
  vars_prompt:
    - name: target_svm
      prompt: "Nom du SVM à configurer"
      private: false
    - name: confirm_deployment
      prompt: "Confirmer le déploiement (yes/no)"
      private: false
      
  pre_tasks:
    - name: Validate confirmation
      fail:
        msg: "Déploiement annulé par l'utilisateur"
      when: confirm_deployment != "yes"
      
    - name: Find SVM configuration
      set_fact:
        current_svm_config: "{{ svm_configs | selectattr('name', 'equalto', target_svm) | first }}"
      failed_when: current_svm_config is not defined
      
  tasks:
    - name: Generate keytab and upload to ONTAP S3
      include_role:
        name: keytab-s3-ontap
      vars:
        svm_name: "{{ target_svm }}"
      delegate_to: "{{ groups['freeipa'][0] }}"
      
    - name: Configure NetApp Kerberos
      include_role:
        name: netapp-kerberos-ontap
      vars:
        svm_name: "{{ target_svm }}"
        lif_name: "{{ current_svm_config.lif_name }}"
        freeipa_ip: "{{ current_svm_config.freeipa_ip }}"
      delegate_to: localhost
      
  post_tasks:
    - name: Schedule S3 cleanup
      cron:
        name: "Cleanup ONTAP S3 keytabs for {{ target_svm }}"
        minute: "0"
        hour: "*/6"
        job: "aws s3 rm s3://{{ s3_bucket }}/keytabs/ --recursive --endpoint-url {{ s3_endpoint }} --exclude '*' --include '*{{ target_svm }}*' --query 'Contents[?LastModified<`$(date -d \"6 hours ago\" -Iseconds)`]'"
        state: present
      delegate_to: "{{ groups['freeipa'][0] }}"
```

### Playbook de nettoyage
```yaml
# playbooks/cleanup-s3-keytabs.yml
---
- name: Cleanup expired keytabs from ONTAP S3
  hosts: freeipa
  tasks:
    - name: List expired keytabs
      command: >
        aws s3api list-objects-v2 
        --bucket {{ s3_bucket }}
        --prefix "keytabs/"
        --endpoint-url {{ s3_endpoint }}# Automation keytab avec S3 et URLs présignées

## Vue d'ensemble de la solution

1. **Génération** du keytab sur FreeIPA
2. **Upload sécurisé** vers S3 avec chiffrement
3. **Génération d'URL présignée** temporaire (1-2h)
4. **Configuration NetApp** avec l'URL présignée
5. **Nettoyage automatique** du keytab S3

## Avantages de cette approche

- ✅ **Sécurisé** : Chiffrement S3 + URLs temporaires
- ✅ **Automatisable** : Scripts + Ansible
- ✅ **Scalable** : Pas de serveur web à maintenir
- ✅ **Traçable** : Logs S3 + CloudTrail
- ✅ **Nettoyage auto** : Expiration des URLs

## 1. Scripts Bash et CLI

### Configuration initiale AWS CLI
```bash
# Installation AWS CLI v2
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install

# Configuration
aws configure
# AWS Access Key ID: AKIA...
# AWS Secret Access Key: ...
# Default region: eu-west-3
# Default output format: json

# Créer le bucket S3 (une seule fois)
BUCKET_NAME="netapp-keytabs-$(date +%Y%m%d)"
aws s3 mb s3://$BUCKET_NAME --region eu-west-3

# Configurer le chiffrement et lifecycle
aws s3api put-bucket-encryption \
  --bucket $BUCKET_NAME \
  --server-side-encryption-configuration '{
    "Rules": [
      {
        "ApplyServerSideEncryptionByDefault": {
          "SSEAlgorithm": "AES256"
        }
      }
    ]
  }'

# Politique de suppression automatique après 24h
cat > lifecycle-policy.json << 'EOF'
{
    "Rules": [
        {
            "ID": "delete-keytabs-24h",
            "Status": "Enabled",
            "Filter": {
                "Prefix": "keytabs/"
            },
            "Expiration": {
                "Days": 1
            }
        }
    ]
}
EOF

aws s3api put-bucket-lifecycle-configuration \
  --bucket $BUCKET_NAME \
  --lifecycle-configuration file://lifecycle-policy.json
```

### Script complet de génération et upload
```bash
#!/bin/bash
# generate-keytab-s3.sh

set -euo pipefail

# Paramètres
SVM_NAME="${1:-}"
DOMAIN="${2:-}"
REALM="${3:-}"
BUCKET_NAME="${4:-netapp-keytabs-$(date +%Y%m%d)}"
EXPIRY_HOURS="${5:-2}"

# Validation des paramètres
if [[ -z "$SVM_NAME" || -z "$DOMAIN" || -z "$REALM" ]]; then
    echo "Usage: $0 <svm_name> <domain> <realm> [bucket_name] [expiry_hours]"
    echo "Exemple: $0 svm01 example.com EXAMPLE.COM netapp-keytabs 2"
    exit 1
fi

# Variables
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
KEYTAB_LOCAL="/tmp/${SVM_NAME}_${TIMESTAMP}.keytab"
S3_KEY="keytabs/${SVM_NAME}_${TIMESTAMP}_$(uuidgen).keytab"

echo "=== Génération du keytab pour ${SVM_NAME}.${DOMAIN} ==="

# 1. Générer le keytab depuis FreeIPA
echo "Génération du keytab..."
ipa-getkeytab -s ipa.${DOMAIN} \
  -p nfs/${SVM_NAME}.${DOMAIN} \
  -k ${KEYTAB_LOCAL}

# Vérifier le contenu
echo "Contenu du keytab:"
klist -k ${KEYTAB_LOCAL}

# 2. Upload vers S3 avec chiffrement
echo "Upload vers S3..."
aws s3 cp ${KEYTAB_LOCAL} s3://${BUCKET_NAME}/${S3_KEY} \
  --server-side-encryption AES256 \
  --metadata "svm=${SVM_NAME},domain=${DOMAIN},generated=$(date -Iseconds)"

# 3. Générer URL présignée
echo "Génération de l'URL présignée..."
EXPIRY_SECONDS=$((EXPIRY_HOURS * 3600))
PRESIGNED_URL=$(aws s3 presign s3://${BUCKET_NAME}/${S3_KEY} \
  --expires-in ${EXPIRY_SECONDS})

# 4. Affichage des résultats
echo ""
echo "=== RÉSULTATS ==="
echo "Keytab S3 Key: ${S3_KEY}"
echo "URL présignée: ${PRESIGNED_URL}"
echo "Expire dans: ${EXPIRY_HOURS} heure(s)"
echo "Expire à: $(date -d "+${EXPIRY_HOURS} hours" '+%Y-%m-%d %H:%M:%S')"
echo ""
echo "=== COMMANDE NETAPP ==="
cat << EOF
vserver nfs kerberos interface enable \\
  -vserver ${SVM_NAME} \\
  -lif <nom_lif> \\
  -spn nfs/${SVM_NAME}.${DOMAIN}@${REALM} \\
  -keytab-uri "${PRESIGNED_URL}"
EOF

# 5. Nettoyage local
rm -f ${KEYTAB_LOCAL}
echo ""
echo "Keytab local supprimé: ${KEYTAB_LOCAL}"
```

### Script de nettoyage S3
```bash
#!/bin/bash
# cleanup-s3-keytabs.sh

BUCKET_NAME="${1:-netapp-keytabs-$(date +%Y%m%d)}"

echo "Nettoyage des keytabs expirés..."

# Lister les objets de plus de 2 heures
aws s3api list-objects-v2 --bucket ${BUCKET_NAME} --prefix "keytabs/" \
  --query "Contents[?LastModified<'$(date -d '2 hours ago' -Iseconds)'].Key" \
  --output text | while read -r key; do
    if [[ -n "$key" ]]; then
        echo "Suppression: $key"
        aws s3 rm s3://${BUCKET_NAME}/${key}
    fi
done

echo "Nettoyage terminé."
```

### Script de configuration NetApp
```bash
#!/bin/bash
# configure-netapp-kerberos.sh

# Paramètres
SVM_NAME="${1:-}"
LIF_NAME="${2:-}"
PRESIGNED_URL="${3:-}"
FREEIPA_IP="${4:-}"
REALM="${5:-}"

if [[ -z "$SVM_NAME" || -z "$LIF_NAME" || -z "$PRESIGNED_URL" || -z "$FREEIPA_IP" || -z "$REALM" ]]; then
    echo "Usage: $0 <svm_name> <lif_name> <presigned_url> <freeipa_ip> <realm>"
    exit 1
fi

echo "=== Configuration Kerberos NetApp ==="

# 1. Configuration du realm Kerberos
echo "Configuration du realm Kerberos..."
ssh netapp-admin@${NETAPP_CLUSTER} << EOF
vserver nfs kerberos config create \\
  -vserver ${SVM_NAME} \\
  -kdc-ip ${FREEIPA_IP} \\
  -kdc-port 88 \\
  -kdc-vendor Other \\
  -admin-server-ip ${FREEIPA_IP} \\
  -admin-server-port 749 \\
  -default-realm ${REALM} \\
  -clock-skew 5

vserver nfs kerberos config show -vserver ${SVM_NAME}
EOF

# 2. Activation Kerberos avec keytab S3
echo "Activation Kerberos avec keytab S3..."
ssh netapp-admin@${NETAPP_CLUSTER} << EOF
vserver nfs kerberos interface enable \\
  -vserver ${SVM_NAME} \\
  -lif ${LIF_NAME} \\
  -spn nfs/${SVM_NAME}.${DOMAIN}@${REALM} \\
  -keytab-uri "${PRESIGNED_URL}"

vserver nfs kerberos interface show -vserver ${SVM_NAME}
EOF

echo "Configuration terminée."
```

## 2. Automation avec Ansible

### Structure des fichiers Ansible
```
ansible/
├── inventories/
│   └── production/
│       ├── hosts.yml
│       └── group_vars/
│           ├── all.yml
│           ├── freeipa.yml
│           └── netapp.yml
├── roles/
│   ├── keytab-s3/
│   │   ├── tasks/main.yml
│   │   ├── vars/main.yml
│   │   └── templates/
│   └── netapp-kerberos/
│       ├── tasks/main.yml
│       └── vars/main.yml
└── playbooks/
    └── deploy-kerberos.yml
```

### Inventaire Ansible
```yaml
# inventories/production/hosts.yml
all:
  children:
    freeipa:
      hosts:
        ipa.example.com:
          ansible_host: 192.168.1.10
    netapp:
      hosts:
        netapp-cluster.example.com:
          ansible_host: 192.168.1.100
          ansible_user: admin
          ansible_connection: netapp.ontap.ontap
```

### Variables globales
```yaml
# inventories/production/group_vars/all.yml
domain: "example.com"
realm: "EXAMPLE.COM"
s3_bucket: "netapp-keytabs-{{ ansible_date_time.date | replace('-', '') }}"
s3_region: "eu-west-3"
keytab_expiry_hours: 2

# Vault encrypted variables
aws_access_key: !vault |
  $ANSIBLE_VAULT;1.1;AES256;dev
  encryption_string_here...
aws_secret_key: !vault |
  $ANSIBLE_VAULT;1.1;AES256;dev
  encryption_string_here...
```

### Variables FreeIPA
```yaml
# inventories/production/group_vars