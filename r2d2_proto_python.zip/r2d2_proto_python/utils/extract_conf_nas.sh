#!/bin/sh
#########################################################################################
# Fichier       :                                                                       #
# Objet         : Extraction de la configiration NAS complete (bleue et rouge)          #
#########################################################################################


REP="/opt/UNS/NETAPP/r2d2_proto/utils"
FIC=/mnt/gconf/nas/conf_nas.csv

cd $REP
./ls_db_inventory.py >$FIC
RET=$?
if [ $RET -ne 0 ]
then
  echo "incident constitution inventaire NAS"
  exit $RET
fi
