#!/opt/UNS/VENV/VENV_CISCO/bin/python3

# -*- coding: utf-8 -*-
# Alimentation de la database


import os
import sys
import context
from datetime import datetime
###A remplacer par logger
from lib.utils.utils import perror

from config import Config

if __name__ == '__main__':
    myconfig = Config(os.path.abspath('..'))
    from lib.db.Inventaire import Inventaire
    from lib.SevenModeApi import SevenModeApi, NaError
    from lib.AppLogger import AppLogger
    myLog=AppLogger(__file__,myconfig.log)


    inventaire=Inventaire(myconfig.database_inventory)

    from lib.db.Referentiel import Referentiel
    ref = Referentiel(myconfig.referentiel_inventory)


    #fas="IBSTOE58"
    #fas="FAS43A.sigce.caisse-epargne.fr"
    fas="FAS44A"
    try:
        print(fas)

        myFiler=SevenModeApi(fas, myconfig.batch_user, myconfig.batch_passwd)
        myFiler.setLogger(myLog)
        # myFiler.cifs_setup("VFTEST3", "workgroup", "TESTAPI")
        # myFiler.add_default_route("VFTEST3","126.245.156.3","default-ipspace")
        # print(ref.get_gateway("126.245.156.104"))
        dict=myFiler.get_version()
        print(dict)
        volume_name="VFPITCAPPN110_ITC_HBM"
        if myFiler.volume_is_snapmirror_destination(volume_name) in "false":
           myFiler.volume_setoption(volume_name,"fs_size_fixed","off")

    except NaError as e:
        d = datetime.now()
        perror(("%.2d%.2d-%.2d%.2d: [errno %s]= %s from %s")%(d.day,d.month,d.hour,d.minute,e.errno,e.message,e.function))
        sys.exit(1)

