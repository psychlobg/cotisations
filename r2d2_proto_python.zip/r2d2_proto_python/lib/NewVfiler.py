import os,sys
from  .SevenModeApi import SevenModeApi
import logging


class NewVfiler(SevenModeApi):
    """ Class de création des Vfilers. Hérite de l'objet FilerAPI.
    """
    CREATEKEYS=("filer","vfiler","aggregat","ipspace","ip","netmask","interface","domain","dns")
    ROOTSIZE="1g"

    def __init__(self,properties,user,password):
        self.properties=properties
        self.checkValues()
        self.filer=properties["filer"]
        super().__init__(self.filer,user,password)
        self.vfilername=properties["vfiler"]
        self.log=None
        self.volume_root_name=None
        return

    def get_vfilername(self):
        return self.vfilername

    def checkValues(self):
        for k in self.CREATEKEYS:
            if k in self.properties.keys():
                if self.properties[k] is None: raise Exception("NewVfiler Error","La valeur de la cle %s est nulle"%(k))
            else:
                raise Exception("NewVfiler Error","Cle %s manquante"%(k))


    def setProperties(self, properties):
        self.properties=properties
        self.checkValues()

    def connect(self):
        """
            Connexion au filer pour valider la liason
        :return:
        """
        version=self.get_version()
        if self.log: self.log.debug(version)
        return version

    def createVolumeRoot(self, rules):
        """
            Création du volume root
        :param size:
        :param rules:
        :return:
        """

        #Creation du volume
        self.volume_create(self.volume_root_name, self.properties["aggregat"], rules.getDefaultSize())
        # setting des options
        self.volume_setoptions(self.volume_root_name, rules.getVolOptions())
        #snapshot reserve
        self.volume_setsnapshot_reserve(self.volume_root_name, rules.getSnapReserve())
        #snashot sched
        self.volume_setsnapshot_sched(self.volume_root_name, rules.getSnapSched())
        #sdeduplication
        self.volume_set_sis(self.volume_root_name, rules.getSisStatus())
        self.volume_sis_sched(self.volume_root_name, rules.getSisSched())

        return

    def createVfiler(self, rules, default_password):
        """
            Creation du vfiler, les properties doivent avoir été définies
        :param rules: regle definissant le paramètrage des volumes
        :param default_password : mot de passe par defaut
        :return:
        """
        if self.properties is None: raise Exception("NewVfiler Error","Create : properties non definis")
                #definition du nom
        self.volume_root_name=rules.makeVolName(self.get_vfilername())
        #creation du volume
        self.createVolumeRoot(rules)

        ipaddresses=[self.properties["ip"]]
        self.vfiler_create(ipaddresses, self.properties["ipspace"], self.volume_root_name, self.properties["vfiler"])
        ipbindings=[
                        {"interface": self.properties["interface"], "ipaddress":self.properties["ip"], "netmask":self.properties["netmask"]}
                    ]
        listedns= self.properties["dns"]
        #code pour le setup (binding ip, dns, user etc)
        self.vfiler_setup(self.vfilername, ipbindings, self.properties["domain"], listedns, default_password)
        #setup du ssh
        self.vfiler_setup_ssh(self.vfilername)
        #enable httpd admin
        self.vfiler_enable_httpd_admin(self.vfilername)

        return




