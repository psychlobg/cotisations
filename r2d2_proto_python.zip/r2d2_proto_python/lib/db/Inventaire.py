# -*- coding: utf-8 -*-
from sqlalchemy import Column
from sqlalchemy.types import Unicode, Integer, DateTime, String
from sqlalchemy import desc
from sqlalchemy.sql import func

from lib.db import Base,create_engine,sessionmaker
from .TablesInventaire import VolumeTable,VfilerTable, AggregatTable, InterfaceTable
from .AbstractBase import AbstractBase,decorate_session

__all__=['Inventaire']
class Inventaire(AbstractBase):
    """ Classe permettant d'attaquer la base Inventaire
    """

    def getOwningFiler(self, type, sObject):
         tTable=None
         if type is "volume":
            tTable=VolumeTable
         elif type is "vfiler":
             tTable=VfilerTable
         liste=None
         if tTable:
            self.session_init()
            aQuery = self.session.query(tTable).filter(tTable.name.startswith(sObject)).all()
            liste=list(map(lambda x: x.filer,aQuery))
            self.session_close()
         return liste

    def getOwningFiler(self, sObject):
        tTables=(VolumeTable,VfilerTable)
        liste=None
        self.session_init()
        for t in tTables:
            aQuery = self.session.query(t).filter(t.name == sObject ).all()
            if aQuery:
                liste=list(map(lambda x: x.filer,aQuery))
        self.session_close()
        return liste

    @decorate_session
    def get_filer_where_vfiler_active(self, vfiler_name):
        """
        Renvoie le nom du filer sur lequel le vfiler est actif
        :param vfiler_name:
        :return:
        """
        t=VfilerTable
        aQuery = self.session.query(t.filer).filter(t.name == vfiler_name,
                                                    t.status == "running" ).one()
        if aQuery:
            return aQuery[0]
        else:
            return None




    def getVolumeAggregat(self, filer, volume):
        t=VolumeTable
        liste=None
        self.session_init()
        aQuery = self.session.query(t).filter(t.name == volume).filter(t.filer == filer )
        a=aQuery.one()
        self.session_close()
        return a.aggregate

    def getAllVolumesFromVfiler(self,filer,vfiler):
        t=VolumeTable
        liste=None
        self.session_init()
        aQuery = self.session.query(t).filter(t.owningVfiler == vfiler).filter(t.filer == filer )
        if aQuery:
            liste=list(map(lambda x: x.name,aQuery))
        self.session_close()
        return liste

    def addVfiler(self,name,status,filer,ip,ipspace):
        """
        :param name: nom du vfiler
        :param status: status
        :param filer: nom du filer auxquel il appartient
        :param ip:
        :param ipspace:
        :return:
        """
        self.session_init()
        vfiler=VfilerTable( name=name, status=status, filer=filer, ip=ip, ipspace=ipspace)
        self.session.add(vfiler)
        self.session.commit()
        self.session_close()

    def addVolume(self, name, state, owningVfiler, filer, sizeTotal, sizeUsed, snapReserve, aggregate):

        new_volume=VolumeTable(    name=name, state=state,
                                   owningVfiler=owningVfiler, filer=filer,
                                   sizeTotal=sizeTotal, sizeUsed=sizeUsed,
                                   snapReserve=snapReserve,aggregate=aggregate
                                )
        self.session_init()
        self.session.add(new_volume)
        self.session.commit()
        self.session_close()


    def addAggregat(self, name, filer, aggrSizeNominal, aggrSizeUsed, volProvisionning, typeDisk):
        """
        :param name:
        :param filer:
        :param aggrSizeNominal:
        :param aggrSizeUsed:
        :param volProvisionning:
        :param typeDisk:
        :return:
        """
        new_aggr = AggregatTable( name=name, filer=filer,
                                  aggrSizeNominal=aggrSizeNominal, aggrSizeUsed=aggrSizeUsed,
                                  volProvisionning = volProvisionning, typeDisk = typeDisk)
        self.session_init()
        self.session.add(new_aggr)
        self.session.commit()
        self.session_close()

    def listAllVolumes(self):
        return self.select_all(VolumeTable)

    def listAllVfiler(self):
        return self.select_all(VfilerTable)

    @decorate_session
    def getNumberOfVfiler(self,filer):
        """
        Retourne le ñombre de vfiler sur un controleur
        :param filer: nom du controleur
        :return:
        """
        return self.session.query(func.count(VfilerTable.name)).filter(VfilerTable.filer==filer).scalar()


    @decorate_session
    def aggregat_select_from_disktype(self,filer, type_disk):
        aQuery = self.session.query(AggregatTable).filter(AggregatTable.filer == filer, AggregatTable.typeDisk == type_disk).all()
        return [ u.name for u in aQuery ]

    @decorate_session
    def aggregat_get_space(self, filer, name):
        """
        Retourne un tuple avec l'espace consommé et l'espace totale utile
        :param filer: nom du filer
        :param name: nom de l'aggregat
        :return: (taille utilisée, taille utile, taille provisionnée)
        """
        aQuery = self.session.query(AggregatTable.aggrSizeUsed,AggregatTable.aggrSizeNominal, AggregatTable.volProvisionning)\
                 .filter(AggregatTable.name == name, AggregatTable.filer == filer).one()
        return aQuery

    @decorate_session
    def aggregat_get_space(self, filer, name):
        """
        Retourne un tuple avec l'espace consommé et l'espace totale utile
        :param filer: nom du filer
        :param name: nom de l'aggregat
        :return: (taille utilisée, taille utile, taille provisionnée)
        """
        aQuery = self.session.query(AggregatTable.aggrSizeUsed,AggregatTable.aggrSizeNominal, AggregatTable.volProvisionning)\
                 .filter(AggregatTable.name == name, AggregatTable.filer == filer).one()
        return aQuery


    @decorate_session
    def addInterface(self,name,ipspace,filer,vlan=999):
        """

        :param name:
        :param ipspace:
        :param filer:
        :param vlan:
        :return:
        """
        new_interface=InterfaceTable(name=name,ipspace=ipspace, filer = filer, vlan = vlan)
        self.session.add(new_interface)

    @decorate_session
    def get_interface(self, filer, vlan):
        """

        :param filer:
        :param vlan:
        :return: (interface, ipspace)
        """

        aQuery= self.session.query(InterfaceTable.name, InterfaceTable.ipspace)\
            .filter(InterfaceTable.vlan == vlan, InterfaceTable.filer == filer ).one()
        if aQuery is None:
            return None, None
        else:
            return aQuery

    @decorate_session
    def vfiler_exist(self,vfiler):
        """
        Test d'existence du vfiler dans l'inventaire
        :param vfiler:
        :return:
        """
        nbre= self.session.query(VfilerTable)\
            .filter(VfilerTable.name == vfiler ).count()

        return ( False if nbre == 0 else True)

    @decorate_session
    def delete_filer(self, filer):
        """
        Supprime de l'inventaire les lignes qui ont le filer en référence.
        :param filer: nom du filer a supprimer
        :return: nombre de lignes supprimées
        """
        nb=0
        for table in [VfilerTable,VolumeTable,InterfaceTable,AggregatTable]:
            nb+=self.session.query(table).filter(table.filer == filer).delete()
        return nb
