#! /bin/bash

for baie in FAS43 
do
	echo "Inventaire ${baie}A"
	./filer_db_inventory.py -n ${baie}A
	echo "Inventaire ${baie}B"
	./filer_db_inventory.py -n ${baie}B
done
 
