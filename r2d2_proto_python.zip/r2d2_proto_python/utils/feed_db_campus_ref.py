#!/opt/UNS/VENV/VENV_CISCO/bin/python3
# -*- coding: utf-8 -*-
# Alimentation du referentiel : campus

import os
import sys
import context
import datetime
###A remplacer par logger
from lib.utils.utils import perror

import argparse

from config import Config


if __name__ == '__main__':
    myconfig = Config(os.path.abspath('..'))
    from lib.db.Referentiel import Referentiel

    parser = argparse.ArgumentParser(description=os.path.basename( sys.argv[0] ))
    parser.add_argument('fichier', help="nom du fichier a charger en base", type=argparse.FileType('r'))
    args=parser.parse_args()
    liste=[]
    for line in args.fichier:
        #print(("# %s #")%line.strip())
        liste.append(line.strip())

    ref = Referentiel(myconfig.referentiel_inventory)
    ref.dropCampusTable()
    ref.createCampusTable()


    for i in range(2,len(liste)):
        #print(liste[i])
        tab=liste[i].split(";")
        if tab[0]:
            print("#",tab[0],tab[1])
            ref.addCampus( name=tab[0], site=tab[1])
    print ("#fin chargement")
    print("##")

