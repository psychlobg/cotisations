#!/opt/UNS/VENV/VENV_CISCO/bin/python3
# -*- coding: utf-8 -*-

import os
import sys
import context
from datetime import datetime
###A remplacer par logger
from lib.utils.utils import perror

from config import Config, AppLogger

def choix_aggregat( inventaire, filer, type_disk, espace_demande ):
    """
    Choix aggregat en fonction typologie de disque et de l'enveloppe demandé
    :param inventaire: Reference sur un objetd de type Inventaire
    :param filer: nom du filer
    :param type_disk: technologie de disque
    :param espace_demande: taille global du vfiler en Gb
    :return: (nom de l'aggregat, tx provisionning) ou None
    """
    retour_aggregat=None,None
    liste_aggregat=inventaire.aggregat_select_from_disktype(filer, type_disk)
    if not liste_aggregat:
        print("Pas d aggregat trouvé avec ce type de disque")

        return retour_aggregat
    winners={}
    for aggregat in liste_aggregat:
        (used,total,prov)=inventaire.aggregat_get_space(filer,aggregat)
        simul=float(used+enveloppe)/(float(total))
        simul_prov=float(prov+enveloppe)/(float(total))

        # if simul > 0.8:
        #    print("PAS BON",aggregat," ",simul)
        # elif simul_prov >= 1.2 :
        #    print("PAS BON prov",aggregat," ",simul)
        # else:
        #    print("BON",aggregat," ",simul," ",simul_prov)
        # si le taux d utilisation est inferieur à 80% et si le taux d'over susbscription est inférieur à 120%
        # on peut utiliser l'aggregat
        if simul < 0.8 and simul_prov <= 1.2:
            winners[aggregat]=simul_prov

    if winners:
        # puisu'il ne peut en rester qu'un
        # on choisit l'aggregat avec le plus petit tx de provisonning
        retour_aggregat=min(winners, key=lambda key: winners[key])
        return retour_aggregat,winners[retour_aggregat]
    else:
        return retour_aggregat



def get_filer_information( inventaire, filer, enveloppe, police):
    """
    Recupere le nombre de vfiler et un aggregat eligible à la creation d'un vfiler
    :param inventaire : Reference sur un objetd de type Inventaire
    :param filer: nom du vfiler
    :param enveloppe: taille finale estimée du vfiler
    :param police: choix de la police pour la vitesse des disques
    :return: None | (
    """
    vide = (None,None,None)
    type=ref.get_disktype_from_police(filer,police)
    if type is None:
        return vide

    (aggr,prov)=choix_aggregat(inventaire,filer,type,enveloppe)
    if aggr is None:
        return vide
    nb=inventaire.getNumberOfVfiler(filer)
    return nb,aggr,prov

def choix_filer(liste_filers, inventaire, enveloppe, police):
    """

    :param self:
    :param liste_filers:
    :param inventaire:
    :param enveloppe:
    :param police:
    :return:
    """
    primaryFilers={}
    for filer in liste_filers:
        (nb_vfiler,aggr_name, prov)=get_filer_information(inventaire, filer, enveloppe, police)
        if aggr_name is not None:
            primaryFilers[filer] = (nb_vfiler,aggr_name, prov)
    # on choist le controleur qui a le moin de vfiler.
    if primaryFilers:
        mini=min(primaryFilers, key=lambda key: primaryFilers[key][0])
        return mini, primaryFilers[mini][1]
    else:
        myLog.error("%s Pas d'aggregat eligible pour ajouter %s Gb"%(liste_filers, enveloppe))
        return None,None

def get_filers_mysys_prd(replication, appli):
    """
    Retourne trois tableaux primary_filers,secondary_filers, secondary_filers = None
    :param environment:
    :param replication:
    :param appli:
    :return:
    """
    primary_filers = None
    secondary_filers = None
    tertiary_filers = None
    if replication == "1+1":
            if appli == "BUR":
                if site == "SIRIUS":
                        primary_filers=["FAS47A","FAS47B"]
                        secondary_filers=["FAS49A","FAS49B"]
                else:
                    primary_filers=["FAS49A","FAS49B"]
                    secondary_filers=["FAS47A","FAS47B"]
            elif appli == "OSSV":
                if site == "SIRIUS":
                    primary_filers=["FAS48A","FAS48B"]
                    secondary_filers=["FAS50A","FAS50B"]
                else:
                    primary_filers=["FAS50A","FAS50B"]
                    secondary_filers=["FAS48A","FAS48B"]
            else:
                if site == "SIRIUS":
                    primary_filers=["FAS46A","FAS46B"]
                    secondary_filers=["FAS44A","FAS44B"]
                elif site == "SAPHIR":
                    primary_filers=["FAS43A","FAS43B"]
                    secondary_filers=["FAS46A","FAS46B"]
                elif site == "TOPAZE":
                    primary_filers=["FAS44A","FAS44B"]
                    secondary_filers=["FAS46A","FAS46B"]
    elif replication == "2+1":
            primary_filers=["FAS43A","FAS43B"]
            secondary_filers=["FAS44A","FAS44B"]
            tertiary_filers=["FAS46A","FAS46B"]
    elif replication == "1+0":
            if site == "SAPHIR":
                primary_filers=["FAS43A","FAS43B"]
            elif site == "TOPAZE":
                primary_filers=["FAS44A","FAS44B"]
            elif site == "SIRIUS":
                primary_filers=["FAS46A","FAS46B"]
    return primary_filers,secondary_filers,tertiary_filers

def get_filers_mysys_maq(replication, appli):
    """

    :param replication:
    :param appli:
    :return:
    """
    primary_filers = None
    secondary_filers = None
    tertiary_filers = None
    if replication == "1+1":
        if site == "SIRIUS":
            primary_filers=["FAS82A","FAS82B"]
            secondary_filers=["FAS81A","FAS81B"]
        else:
            primary_filers=["FAS81A","FAS81B"]
            secondary_filers=["FAS82A","FAS82B"]
    else:
        if site == "SIRIUS":
            primary_filers=["FAS82A","FAS82B"]
        else:
            primary_filers=["FAS81A","FAS81B"]
    return primary_filers,secondary_filers,tertiary_filers

def get_filers_eqx_prd(replication, appli):
    """

    :param replication:
    :param appli:
    :return:
    """
    primary_filers = None
    secondary_filers = None
    tertiary_filers = None
    if replication == "METRO":
        if site == "SAPHIR":
            primary_filers=["IBSTOE50"]
        else:
            primary_filers=["IBSTOE51"]

    return primary_filers,secondary_filers,tertiary_filers


def check_free_ip(filer, vlan):
    """
    Retourne True s'il y a des ip de disponible pour ce filer
    :param filer:
    :param vlan:
    :return True |False:
    """
    ip,netmask,gateway,campus=get_free_ip(filer, vlan)
    return True if ip else False

def get_free_ip(filer, vlan):
    """

    :param filer:
    :param vlan:
    :return: (ip,netmask,gateway,campus)
    """
    campus=ref.get_campus_from_filer(filer)
    ip,netmask,gateway=ref.get_free_ip(vlan,campus)
    if ip is None:
        myLog.error("Pas d'ip disponible dans le vlan %s"%vlan)
    return ip,netmask,gateway,campus


def create_vfilerDR(vfiler_name, filer, aggregat, vlan, filersource):
    """
    :param vfiler_name:
    :param filer:
    :param aggregat:
    :param vlan:
    :param filersource:
    :return:
    """
    myLog.info("Mise en place du vfiler DR")
    ip,netmask,gateway,campus=get_free_ip(filer,vlan)
    myLog.info("le campus du filer %s est %s" % (filer, campus))
    # ip,netmask,gateway=ref.get_free_ip(vlan,campus)
    if ip is None:
        myLog.error("Pas d'ip disponible dans le vlan %s"%vlan)
        sys.exit(5)

    myLog.info("IP %s %s %s"%(ip,netmask,gateway))
    dns=ref.get_domain(domain,campus)
    myLog.info("infos domaine : %s %s"%(domain,dns))

    (interface, ipspace)=inventaire.get_interface(filer, vlan)
    myLog.info("interface %s - ipspace %s"%(interface,ipspace) )
    vfiler_properties={}
    vfiler_properties["filer"]=filer
    vfiler_properties["vfiler"]=vfiler_name
    vfiler_properties["aggregat"]=aggregat
    vfiler_properties["ip_info"]=[{"interface":interface,"ip-address":ip,"netmask":netmask}]
    vfiler_properties["dns"]=dns
    vfiler_properties["remote_vfiler_location"]={"filer":filersource, "vfiler": vfiler_name}
    print(vfiler_properties["remote_vfiler_location"])
    vfiler_properties["remote_authentification"]={"username":myconfig.batch_user,"password":myconfig.batch_passwd}

    try:
        return
        vfiler=NewVfilerDR(vfiler_properties,myconfig.batch_user, myconfig.batch_passwd)
        vfiler.setLogger(myLog)
        vfiler.setProperties(vfiler_properties)
        vfiler.createVfilerDR(volume_creation_rule)
        ref.associate_interface_with_vfiler(ip=ip,vfiler=vfiler_name)
        myLog.info("création du vfiler DR %s OK"%vfiler_name)
        myLog.info("#! Pensez à corriger le schedule dans snapmirror.conf du filer %s"%filer)

    except NaError as e:
        myLog.error(("%s - [errno %s]= %s ")%(e.function, e.errno,e.message))
    except Exception as e:
        myLog.error(e.args)


def create_vfiler(vfiler_name, filer, aggregat, vlan):
        myLog.info("obtention ip")
        ip,netmask,gateway,campus=get_free_ip(filer,vlan)
        # campus=ref.get_campus_from_filer(filer)
        myLog.info("le campus du filer %s est %s" % (filer, campus))
        # ip,netmask,gateway=ref.get_free_ip(vlan,campus)
        if ip is None:
            myLog.error("Pas d'ip disponible dans le vlan %s"%vlan)
            sys.exit(5)

        myLog.info("IP %s %s %s"%(ip,netmask,gateway))
        dns=ref.get_domain(domain,campus)
        myLog.info("infos domaine : %s %s"%(domain,dns))

        (interface, ipspace)=inventaire.get_interface(filer, vlan)
        myLog.info("interface %s - ipspace %s"%(interface,ipspace) )

        #CREATEKEYS=("filer","vfiler","aggregat","ipspace","ip","netmask","interface","domain","dns")
        vfiler_properties={}
        vfiler_properties["filer"]=filer_primaire
        vfiler_properties["vfiler"]=vfiler_name
        vfiler_properties["aggregat"]=aggr_primaire
        vfiler_properties["ipspace"]=ipspace
        vfiler_properties["ip"]=ip
        vfiler_properties["netmask"]=netmask
        vfiler_properties["interface"]=interface
        vfiler_properties["domain"]=domain
        vfiler_properties["dns"]=dns

        try:
            return
            vfiler=NewVfiler(vfiler_properties,myconfig.batch_user, myconfig.batch_passwd)
            vfiler.setLogger(myLog)
            vfiler.setProperties(vfiler_properties)
            vfiler.createVfiler(volume_creation_rule,"àchanger1234")
            ref.associate_interface_with_vfiler(ip=ip,vfiler=vfiler_name)
            myLog.info("création du vfiler %s OK"%vfiler_name)
        except NaError as e:
            myLog.error(("%s - [errno %s]= %s ")%(e.function, e.errno,e.message))
        except Exception as e:
            myLog.error(e.args)


if __name__ == '__main__':
    global volume_creation_rule
    global myconfig
    myconfig = Config(os.path.abspath('..'))
    global myLog
    myLog=AppLogger(__file__,myconfig.log)
    from lib.db.Inventaire import Inventaire

    from lib.SevenModeApi import SevenModeApi, NaError
    from lib.NewVfiler import NewVfiler
    from lib.NewVfilerDR import NewVfilerDR

    inventaire=Inventaire(myconfig.database_inventory)
    from lib.db.Referentiel import Referentiel
    ref = Referentiel(myconfig.referentiel_inventory)

    vfiler_name="VFTEST2"
    client="MYSYS"
    replication="1+1"
    police="platine"
    site="SIRIUS"
    appli="AUTRE"
    domain="sigce.caisse-epargne.fr"
    environment="MAQ"
    vlan="156"

    volume_creation_rule=myconfig.getRule(client, "root")

    enveloppe=1

    # Determination des controleurs
    primary_filers = None
    secondary_filers = None
    tertiary_filers = None
    if client == "MYSYS":
        if environment == "PRD":
            primary_filers,secondary_filers,tertiary_filers = get_filers_mysys_prd(replication, appli)
        elif environment == "MAQ":
            primary_filers,secondary_filers,tertiary_filers = get_filers_mysys_maq(replication, appli)
    elif client == "EQX":
         if environment == "PRD":
              primary_filers,secondary_filers,tertiary_filers = get_filers_eqx_prd(replication, appli)
    else:
        sys.exit(1)

    #PRECHECK
    if inventaire.vfiler_exist(vfiler_name):
        myLog.error("le vfiler %s existe déjà !"%vfiler_name)
        sys.exit(1)

    filer_primaire, aggr_primaire = choix_filer(primary_filers, inventaire, enveloppe, police)


    if filer_primaire and aggr_primaire and check_free_ip(filer_primaire,vlan):
        myLog.info("Vfiler nominal : %s sur %s" %(filer_primaire,aggr_primaire))
    else:
        myLog.error("Probleme sur la determination du filer, de l'aggregat ou de l'ip")
        sys.exit(1)

    if secondary_filers:
        second, aggr_second= choix_filer(secondary_filers,inventaire, enveloppe, police )
        if second and aggr_second and check_free_ip(second,vlan):
            myLog.info("Vfiler DR : %s sur %s" %(second,aggr_second))
        else:
            myLog.error("Probleme sur la determination du filer, de l'aggregat ou de l'ip")
            sys.exit(1)

    if tertiary_filers:
        ter,aggr_ter= choix_filer(tertiary_filers,inventaire, enveloppe, police )
        if ter and aggr_ter and check_free_ip(ter,vlan):
            myLog.info("Vfiler DR : %s sur %s" %(ter,aggr_ter))
        else:
            myLog.error("Probleme sur la determination du filer, de l'aggregat ou de l'ip")
            sys.exit(1)


    # CREATION
    if filer_primaire:
        create_vfiler(vfiler_name, filer_primaire, aggr_primaire, vlan)

    filersource=filer_primaire+"-MIRROR"

    if secondary_filers and second:
        create_vfilerDR(vfiler_name, second, aggr_second, vlan, filersource)

    if tertiary_filers and ter:
        create_vfilerDR(vfiler_name, ter, aggr_ter, vlan, filersource)
















