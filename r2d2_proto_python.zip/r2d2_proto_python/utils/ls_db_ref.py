#!/opt/UNS/VENV/VENV_CISCO/bin/python3
# -*- coding: utf-8 -*-

import os
import sys
import context
import datetime
from lib.utils.utils import perror

from config import Config

if __name__ == '__main__':
    myconfig = Config(os.path.abspath('..'))
    from lib.db.Referentiel import Referentiel

    ref = Referentiel(myconfig.referentiel_inventory)
    result=ref.listAllFiler()
    print("# liste des filers stockés")
    for r in result:
        print( ("%5d \t %10s \t%16s \t%10s \t%8s \t%4s \t%4s")%
               (r["id"], r["name"],r["ip"], r["site"], r["client"],
                r["environment"], r["application"])
               )

    result2=ref.listPoolIP()
    print("# liste POOL IP")
    for r in result2:
        print( (" %20s \t%20s \t%20s \t%8s \t%20s \t%20s")%
               ( r["ip"],r["netmask"], r["gateway"], r["vlan"],
                r["campus"], r["vfiler"])
               )

