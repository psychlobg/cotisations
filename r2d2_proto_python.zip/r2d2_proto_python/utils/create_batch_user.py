#!/opt/UNS/VENV/VENV_CISCO/bin/python3
# -*- coding: utf-8 -*-

import os
import sys
import context
import datetime
import json
from lib.db.Inventaire import Inventaire
from lib.SevenModeApi import SevenModeApi, NaError
from lib.AppLogger import AppLogger

from config import Config
myconfig = Config(os.path.abspath('..'))
myLog=AppLogger(__file__,myconfig.log)


userDefinition=sys.path[0]+"/conf/user_r2d2.json"

with open(userDefinition,"r") as f:
    userObj=json.load(f)

try:
    fas=sys.argv[1]
    print(fas)
    #myFiler=SevenModeApi(fas, myconfig.batch_user, myconfig.batch_passwd)
    myFiler=SevenModeApi(fas, "root", "WXXXXXX")
    myFiler.setLogger(myLog)
    myLog.info( ("%s -Ajout du role")%(fas)  )
    myFiler.useradmin_role_add(userObj["role-name"],userObj["role-capabilities"])
    myLog.info( ("%s -Ajout du role")%(fas)  )
    myFiler.useradmin_group_add(userObj["group-name"],userObj["group-roles"])
    myLog.info( ("%s -Ajout du user")%(fas)  )
    myFiler.useradmin_user_add(config.batchuser,config.batchpassword,userObj["group-name"])

except NaError as e:
        myLog.error(("%s - [errno %s]= %s ")%(e.function, e.errno,e.message))

