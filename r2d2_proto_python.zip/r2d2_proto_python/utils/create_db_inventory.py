#!/opt/UNS/VENV/VENV_CISCO/bin/python3
# -*- coding: utf-8 -*-
# Creation de la database

import os
import sys
import context
from config import Config

if __name__ == '__main__':
    myconfig = Config(os.path.abspath('..'))
    print(myconfig.base_dir)
    from lib.db import Base,create_engine
    from lib.db.TablesInventaire import VfilerTable,VolumeTable,AggregatTable, InterfaceTable

    engine = create_engine('sqlite:///' + myconfig.database_inventory)
    # Create all tables in the engine. This is equivalent to "Create Table"
    # statements in raw SQL.
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
