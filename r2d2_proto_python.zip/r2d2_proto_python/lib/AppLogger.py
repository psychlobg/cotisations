import sys
import logging
import logging.handlers
import os


class AppLogger(object):
    """Classe pour le logging des actions dans un fichier"""
    def __init__(self, loggername, logfile):

        self.root = logging.getLogger(loggername)

        self.root.setLevel(logging.DEBUG)
        self.formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s -  %(message)s')

        #stdout handler
        self.handlerStdout = logging.StreamHandler(sys.stdout)
        self.handlerStdout.setLevel(logging.INFO)
        self.handlerStdout.setFormatter(self.formatter)
        self.root.addHandler(self.handlerStdout)

        #Logging file handle
        self.handlerFile = logging.handlers.RotatingFileHandler(logfile,20000,7,)
        self.handlerFile.setLevel(logging.DEBUG)
        self.handlerFile.setFormatter(self.formatter)
        self.root.addHandler(self.handlerFile)

    def debug(self, m):
        self.root.debug(m)

    def info(self, m):
        self.root.info(m)

    def warning(self, m):
        self.root.warning(m)

    def error(self, m):
        self.root.error(m)

