# Configuration d'Apache et Nginx pour l'authentification Kerberos avec Active Directory et LDAP en fallback

Ce document décrit la procédure pour configurer des serveurs Apache et Nginx afin d'utiliser **Kerberos** pour l'authentification du serveur auprès d'Active Directory (AD), avec **Kerberos** (SSO) comme méthode principale et **LDAP** comme fallback pour l'authentification des clients Windows et Linux. Il inclut les étapes pour ajouter le site web (`webserver.example.com`) aux sites de confiance dans Firefox et Chrome sur Windows, ainsi que les tests avec `curl` pour vérifier l'accès au site.

## Hypothèses
- Domaine AD : `EXAMPLE.COM`
- FQDN du serveur : `webserver.example.com`
- Le site utilise **HTTPS** pour sécuriser les identifiants LDAP.
- Clients : Windows (joints au domaine) et Linux (avec Kerberos configuré).
- LDAP : Utilisé comme fallback pour valider les identifiants via authentification basique.

## Prérequis
- **Serveur** : Apache ou Nginx sur Linux (par exemple, Ubuntu/Debian).
- **AD** : 
  - Accès à un contrôleur de domaine avec droits pour créer un compte de service et un keytab.
  - Un compte bind LDAP (ex. : `CN=bind_user,OU=Users,DC=example,DC=com` avec mot de passe).
- **DNS** : `webserver.example.com` doit être résolu correctement dans AD.
- **Paquets** :
  - Apache : `libapache2-mod-auth-kerb`, `libapache2-mod-authnz-ldap`
  - Nginx : `ngx_http_auth_spnego_module` (peut nécessiter compilation), `ngx_http_auth_ldap_module` (ou un backend LDAP)
  - Kerberos : `krb5-user`
  - `curl` avec support Kerberos (`libcurl4-gnutls-dev` ou `libcurl4-openssl-dev` sur Linux).
- **Certificat SSL** : Nécessaire pour HTTPS.
- **Clients** :
  - Windows : Machines jointes au domaine.
  - Linux : Configurées avec `/etc/krb5.conf` et tickets Kerberos.

## 1. Configuration du serveur

### 1.1 Créer un compte de service et un keytab dans AD
1. **Créer un compte de service** :
   - Sur le contrôleur de domaine (Windows) :
     ```powershell
     New-ADUser -Name "HTTP_webserver" -UserPrincipalName "HTTP/webserver.example.com@EXAMPLE.COM" -AccountPassword (ConvertTo-SecureString "P@ssw0rd" -AsPlainText -Force) -Enabled $true
     setspn -A HTTP/webserver.example.com@EXAMPLE.COM HTTP_webserver
     ```

2. **Générer un keytab** :
   ```powershell
   ktpass -princ HTTP/webserver.example.com@EXAMPLE.COM -mapuser HTTP_webserver@EXAMPLE.COM -crypto ALL -ptype KRB5_NT_PRINCIPAL -pass P@ssw0rd -out webserver.keytab
   ```
   - Transférez `webserver.keytab` sur le serveur Linux (par exemple, via SCP).

3. **Installer le keytab** :
   ```bash
   mv webserver.keytab /etc/krb5.keytab
   chmod 600 /etc/krb5.keytab
   chown apache:apache /etc/krb5.keytab  # Pour Apache
   chown nginx:nginx /etc/krb5.keytab    # Pour Nginx
   ```

### 1.2 Configurer Kerberos sur le serveur Linux
1. **Installer les outils Kerberos** :
   ```bash
   apt-get install krb5-user
   ```

2. **Configurer `/etc/krb5.conf`** :
   ```ini
   [libdefaults]
       default_realm = EXAMPLE.COM
       dns_lookup_realm = false
       dns_lookup_kdc = false

   [realms]
       EXAMPLE.COM = {
           kdc = dc.example.com
           admin_server = dc.example.com
       }

   [domain_realm]
       .example.com = EXAMPLE.COM
       example.com = EXAMPLE.COM
   ```

3. **Tester le keytab** :
   ```bash
   kinit -k -t /etc/krb5.keytab HTTP/webserver.example.com@EXAMPLE.COM
   klist
   ```
   - Vérifiez qu’un ticket est affiché.

### 1.3 Configurer Apache
1. **Installer les modules Kerberos et LDAP** :
   ```bash
   apt-get install libapache2-mod-auth-kerb libapache2-mod-authnz-ldap
   a2enmod auth_kerb authnz_ldap ldap
   ```

2. **Configurer le site Apache** :
   - Créez ou modifiez `/etc/apache2/sites-available/your-site.conf` :
     ```apache
     <VirtualHost *:443>
         ServerName webserver.example.com
         DocumentRoot /var/www/html

         SSLEngine on
         SSLCertificateFile /path/to/cert.pem
         SSLCertificateKeyFile /path/to/key.pem

         <Directory /var/www/html>
             AuthType Kerberos
             AuthName "Kerberos or LDAP Login"
             KrbMethodNegotiate On
             KrbMethodK5Passwd Off
             KrbServiceName HTTP
             KrbAuthRealms EXAMPLE.COM
             Krb5KeyTab /etc/krb5.keytab

             # Fallback vers LDAP pour authentification basique
             AuthType Basic
             AuthBasicProvider ldap
             AuthLDAPURL "ldaps://dc.example.com:636/OU=Users,DC=example,DC=com?sAMAccountName?sub?(objectClass=*)"
             AuthLDAPBindDN "CN=bind_user,OU=Users,DC=example,DC=com"
             AuthLDAPBindPassword "bind_password"
             AuthLDAPGroupAttribute member
             AuthLDAPGroupAttributeIsDN on
             Require valid-user
         </Directory>
     </VirtualHost>
     ```
   - **Explications** :
     - `KrbMethodNegotiate On` : Active le SSO Kerberos.
     - `KrbMethodK5Passwd Off` : Désactive le fallback Kerberos basique pour forcer LDAP.
     - `AuthBasicProvider ldap` : Valide les identifiants via LDAP.
     - `AuthLDAPURL` : Utilise LDAPS (port 636) pour sécuriser les requêtes LDAP.
     - `SSLEngine on` : Sécurise les identifiants saisis via HTTPS.

3. **Redémarrer Apache** :
   ```bash
   systemctl restart apache2
   ```

### 1.4 Configurer Nginx
- **Note** : Nginx nécessite `ngx_http_auth_spnego_module` pour Kerberos et `ngx_http_auth_ldap_module` (ou un backend) pour LDAP.

1. **Installer les dépendances** :
   ```bash
   apt-get install libkrb5-dev
   ```
   - Pour `ngx_http_auth_ldap_module`, ajoutez un dépôt tiers (ex. : GetPageSpeed) :
     ```bash
     apt-get install apt-transport-https lsb-release ca-certificates
     wget -O /etc/apt/trusted.gpg.d/getpagespeed.gpg https://packages.getpagespeed.com/public.gpg
     echo "deb https://packages.getpagespeed.com/deb stable main" | tee /etc/apt/sources.list.d/getpagespeed.list
     apt-get update
     apt-get install nginx-extras nginx-auth-ldap
     ```

2. **Configurer le site Nginx** :
   - Créez ou modifiez `/etc/nginx/sites-available/your-site` :
     ```nginx
     server {
         listen 443 ssl;
         server_name webserver.example.com;

         ssl_certificate /path/to/cert.pem;
         ssl_certificate_key /path/to/key.pem;

         # LDAP configuration
         ldap_server ad_server {
             url "ldaps://dc.example.com:636/OU=Users,DC=example,DC=com?sAMAccountName?sub?(objectClass=*)";
             binddn "CN=bind_user,OU=Users,DC=example,DC=com";
             binddn_passwd "bind_password";
             group_attribute member;
             group_attribute_is_dn on;
             require valid-user;
         }

         location / {
             auth_gss on;
             auth_gss_keytab /etc/krb5.keytab;
             auth_gss_service_name HTTP/webserver.example.com@EXAMPLE.COM;
             auth_gss_realm EXAMPLE.COM;

             # Fallback vers LDAP
             auth_ldap "Kerberos or LDAP Login";
             auth_ldap_servers ad_server;

             root /var/www/html;
             index index.html;
         }
     }
     ```
   - **Alternative avec backend** :
     - Si `ngx_http_auth_ldap_module` n'est pas disponible, configurez un backend (ex. : script Python/PHP) pour valider les identifiants LDAP via `auth_request` :
       ```nginx
       location /auth {
           internal;
           proxy_pass http://localhost:8888; # Backend LDAP
           proxy_pass_request_body off;
           proxy_set_header Content-Length "";
           proxy_set_header X-LDAP-URL "ldaps://dc.example.com:636/OU=Users,DC=example,DC=com?sAMAccountName";
           proxy_set_header X-LDAP-BindDN "CN=bind_user,OU=Users,DC=example,DC=com";
           proxy_set_header X-LDAP-BindPass "bind_password";
       }
       ```

3. **Redémarrer Nginx** :
   ```bash
   systemctl restart nginx
   ```

## 2. Configuration des clients

### 2.1 Clients Windows

#### Firefox : Ajouter aux sites de confiance
1. **Ouvrir les paramètres avancés** :
   - Lancez Firefox.
   - Tapez `about:config` dans la barre d’adresse.
   - Cliquez sur **Accepter le risque et continuer**.

2. **Configurer les URI de confiance** :
   - Recherchez :
     ```
     network.negotiate-auth.trusted-uris
     ```
   - Double-cliquez et ajoutez :
     ```
     webserver.example.com
     ```
   - Pour plusieurs serveurs : `webserver.example.com,otherserver.example.com`.

3. **(Facultatif) Configurer la délégation** :
   - Si nécessaire :
     ```
     network.negotiate-auth.delegation-uris
     ```
     - Ajoutez : `webserver.example.com`.

4. **Vérifier les tickets Kerberos** :
   - Assurez-vous que la machine est jointe au domaine :
     ```powershell
     systeminfo | findstr /B /C:"Domain"
     ```
   - Vérifiez les tickets :
     ```cmd
     klist
     ```

#### Chrome : Ajouter aux sites de confiance
1. **Ajouter à la zone Intranet local/Sites de confiance** :
   - Ouvrez **Panneau de configuration** > **Options Internet**.
   - Allez dans **Sécurité** > **Intranet local** ou **Sites de confiance** > **Sites**.
   - Ajoutez : `https://webserver.example.com`.
   - Décochez **Exiger une vérification du serveur (https:)** si vous testez en HTTP (non recommandé).

2. **(Alternative) Configurer via GPO** :
   - Ouvrez `gpedit.msc` ou utilisez un GPO AD.
   - Naviguez vers :
     ```
     Configuration utilisateur > Stratégies > Modèles d'administration > Google > Google Chrome
     ```
   - Activez **Liste des URL de l’authentification intégrée** :
     - Ajoutez : `webserver.example.com`.
   - (Facultatif) Activez **Liste des URL pour la délégation d’identifiants Kerberos** :
     - Ajoutez : `webserver.example.com`.

3. **(Alternative) Configurer via le registre** :
   ```powershell
   Set-ItemProperty -Path "HKLM:\Software\Policies\Google\Chrome\AuthServerWhitelist" -Name "AuthServerWhitelist" -Value "webserver.example.com"
   Set-ItemProperty -Path "HKLM:\Software\Policies\Google\Chrome\AuthNegotiateDelegateWhitelist" -Name "AuthNegotiateDelegateWhitelist" -Value "webserver.example.com"
   ```

4. **Vérifier les tickets Kerberos** :
   ```cmd
   klist
   ```

#### Edge (pour complétude)
- Suivez les mêmes étapes que pour Chrome (Options Internet, GPO, ou registre).

### 2.2 Clients Linux
1. **Configurer Kerberos** :
   - Installez les outils :
     ```bash
     apt-get install krb5-user
     ```
   - Configurez `/etc/krb5.conf` (voir section 1.2).
   - Obtenez un ticket :
     ```bash
     kinit username@EXAMPLE.COM
     klist
     ```

2. **Configurer Firefox** :
   - Comme pour Windows, ajoutez `webserver.example.com` à `network.negotiate-auth.trusted-uris` dans `about:config`.

3. **Configurer Chrome** :
   - Lancez avec :
     ```bash
     google-chrome --auth-server-whitelist="webserver.example.com" --auth-negotiate-delegate-whitelist="webserver.example.com"
     ```

4. **(Facultatif) Joindre le domaine** :
   ```bash
   apt-get install realmd sssd krb5-user
   realm join EXAMPLE.COM -U administrator
   ```
   - Configurez `/etc/sssd/sssd.conf` :
     ```ini
     [sssd]
     domains = EXAMPLE.COM
     services = nss, pam

     [domain/EXAMPLE.COM]
     id_provider = ad
     auth_provider = ad
     krb5_realm = EXAMPLE.COM
     ```
   - Redémarrez SSSD :
     ```bash
     systemctl restart sssd
     ```

5. **Authentification LDAP** :
   - Si Kerberos échoue, saisissez `username@EXAMPLE.COM` (ou `EXAMPLE\username`) et le mot de passe dans la boîte de dialogue.

## 3. Tests et dépannage

### Tests
- **Kerberos (SSO)** :
  - Depuis Windows (joint au domaine) ou Linux (avec `kinit`), accédez à `https://webserver.example.com` avec Firefox/Chrome.
  - Vérifiez que le SSO fonctionne sans invite.
- **Authentification LDAP** :
  - Désactivez Kerberos dans Firefox (supprimez `webserver.example.com` de `network.negotiate-auth.trusted-uris`) ou utilisez un client sans ticket.
  - Saisissez `username@EXAMPLE.COM` (ou `EXAMPLE\username`) et le mot de passe dans la boîte de dialogue.

### Tests avec `curl`
#### Tester l’authentification Kerberos
1. **Sur Linux** :
   - Configurez `/etc/krb5.conf` (voir section 1.2).
   - Obtenez un ticket Kerberos :
     ```bash
     kinit username@EXAMPLE.COM
     klist
     ```
   - Testez avec `curl` :
     ```bash
     curl --negotiate -u : https://webserver.example.com
     ```
     - Si erreur SSL (certificat auto-signé) :
       ```bash
       curl --negotiate -u : -k https://webserver.example.com
       ```

2. **Sur Windows** :
   - Vérifiez que la machine est jointe au domaine :
     ```powershell
     systeminfo | findstr /B /C:"Domain"
     ```
   - Vérifiez les tickets :
     ```cmd
     klist
     ```
   - Testez avec `curl` :
     ```powershell
     curl --negotiate -u : https://webserver.example.com
     ```
     - Si erreur SSL :
       ```powershell
       curl --negotiate -u : -k https://webserver.example.com
       ```

3. **Résultat attendu** :
   - Si réussi, `curl` affiche le contenu de la page (par exemple, HTML).
   - Si erreur 401 (Unauthorized), vérifiez le ticket Kerberos, la configuration du serveur, ou les logs.

#### Tester l’authentification LDAP
1. **Sur Linux/Windows** :
   - Testez avec des identifiants AD :
     ```bash
     curl -u username@EXAMPLE.COM:password https://webserver.example.com
     ```
     - Si erreur SSL :
       ```bash
       curl -u username@EXAMPLE.COM:password -k https://webserver.example.com
       ```

2. **Résultat attendu** :
   - Si réussi, `curl` affiche le contenu de la page.
   - Si erreur 401, vérifiez les identifiants, l’URL LDAP, le compte bind, ou les logs.

### Dépannage
- **Kerberos échoue** :
  - Vérifiez le keytab : `kinit -k -t /etc/krb5.keytab HTTP/webserver.example.com@EXAMPLE.COM`.
  - Vérifiez `/etc/krb5.conf`.
  - Assurez-vous que `webserver.example.com` est résolu (DNS) :
    ```bash
    nslookup webserver.example.com
    ```
  - Vérifiez les tickets : `klist` (Windows) ou `klist` après `kinit` (Linux).
- **Authentification LDAP échoue** :
  - Vérifiez HTTPS (certificat SSL valide).
  - Vérifiez les identifiants (`username@EXAMPLE.COM` ou `EXAMPLE\username`).
  - Vérifiez l’URL LDAP et le compte bind (`AuthLDAPBindDN`, `AuthLDAPBindPassword`).
  - Consultez les logs : `/var/log/apache2/error.log` (Apache) ou `/var/log/nginx/error.log` (Nginx).
- **Navigateur** :
  - Confirmez que `webserver.example.com` est dans les sites de confiance.
  - Vérifiez la synchronisation de l’heure (Kerberos est sensible aux décalages).
- **Erreur SSL avec `curl`** :
  - Utilisez `-k` pour les tests, mais configurez un certificat SSL valide pour la production.

## 4. Remarques
- **HTTPS** : Obligatoire pour sécuriser les identifiants LDAP saisis via authentification basique.
- **LDAPS** : Préférez `ldaps://` (port 636) dans `AuthLDAPURL` pour sécuriser les requêtes LDAP.
- **Kerberos prioritaire** : Le serveur tente Kerberos en premier, puis LDAP si Kerberos échoue.
- **Clients non configurés** : Sans ticket Kerberos, les utilisateurs saisissent leurs identifiants manuellement via LDAP.
- **Nginx** : L’authentification LDAP nécessite un module tiers (`ngx_http_auth_ldap_module`) ou un backend.
- **Documentation** : Consultez `mod_auth_kerb` et `mod_authnz_ldap` (Apache) ou `ngx_http_auth_spnego_module` et `ngx_http_auth_ldap_module` (Nginx).