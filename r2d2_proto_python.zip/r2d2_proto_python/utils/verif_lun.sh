#!/bin/sh
#########################################################################################
# Fichier       : /home/ADMB0000419/verif_lun.sh                                        #
# Objet         : verif que la taille des volumes - reserve soit > cumul des lun        #
#                                                                                       #
#########################################################################################

# Verification des parametres
NB_PAR=$#
NOM_NETAPP=$1

if [ $NB_PAR != 1 ]
then
  echo "Erreur : lancez moi avec le nom du controleur NetApp"
  exit 1
fi

REP=/home/ADMB0000419

ssh root@$NOM_NETAPP df >/tmp/df_$NOM_NETAPP
grep -v snapshot /tmp/df_$NOM_NETAPP >/tmp/volumes_$NOM_NETAPP
grep snapshot /tmp/df_$NOM_NETAPP | sed -e 's/snapshot   /snapshot  /' | sed -e 's/snapshot  /snapshot /' >/tmp/snapshot_$NOM_NETAPP
ssh root@$NOM_NETAPP snap reserve >/tmp/reserve_$NOM_NETAPP
ssh root@$NOM_NETAPP lun show >/tmp/lun_tmp_$NOM_NETAPP
grep Qtree /tmp/lun_tmp_$NOM_NETAPP >/tmp/lun_$NOM_NETAPP
rm /tmp/df_$NOM_NETAPP /tmp/lun_tmp_$NOM_NETAPP
echo " " >/tmp/rapport_$NOM_NETAPP.txt
echo "  Controle des tailles volumes / lun pour " $NOM_NETAPP >>/tmp/rapport_$NOM_NETAPP.txt
echo " " >>/tmp/rapport_$NOM_NETAPP.txt

while read VOLUMES
do
  VOL=`echo $VOLUMES | cut -f3 -d"/"`
  TAILLE=`echo $VOLUMES | cut -f2 -d" "`
  TSNAP=`grep $VOL /tmp/snapshot_$NOM_NETAPP | awk -F"snapshot " ' { print $2 }' | cut -f1 -d" "`
  TOT=$((TAILLE+TSNAP))
  Tgo=$((TOT/1048576))
# PRES=`echo $VOL | grep $VOL /tmp/reserve_$NOM_NETAPP | cut -f7 -d" " | sed -e 's/%//g'`
# VRES=`grep $VOL /tmp/reserve_$NOM_NETAPP | cut -f9 -d" " | sed -e 's/ //g'`
  VRES=`grep $VOL: /tmp/reserve_$NOM_NETAPP | awk -F" or " ' { print $2 }' | cut -f1 -d" "`
# SNAP=$((VRES*PRES/100))
# Sgo=$((SNAP/1048576))
  Sgo=$((VRES/1048576))
  RESTE=$((Tgo-Sgo))
  echo Volume $VOL Taille $Tgo Snap_reserve $Sgo Reste $RESTE >>/tmp/rapport_$NOM_NETAPP.txt
  grep "/vol/$VOL" /tmp/lun_$NOM_NETAPP | cut -f1 -d"(" >/tmp/lun_$NOM_NETAPP_$VOL
  TOTlun=0
  while read LUNS
  do
    Tlun=`echo $LUNS | cut -f2 -d " "` 
    UNIT=`echo $Tlun | awk '{print(substr($0, length($0), length($0)))}'`
    case $UNIT in
      "g")  Glun=`echo $Tlun | sed -e 's/g//g'`;;
      "t")  Glun=`echo $Tlun | sed -e 's/t//g'`
            echo "($Glun*1024)" | bc 1>/dev/null;;
      "m")  Glun=`echo $Tlun | sed -e 's/m//g'`
            echo "($Glun/1024)" | bc 1>/dev/null;;
    esac
    TOTlun=`echo "($Glun+$TOTlun)" | bc`
    TOTent=`echo $TOTlun | cut -f1 -d"."`
    if (( $TOTent > $RESTE ))
    then
      echo "*** ATTENTION *** Le cumul des LUNs ($TOTent go) est superieur a la taille du volume moins le snap reserve ($RESTE go)" >>/tmp/rapport_$NOM_NETAPP.txt
    fi
  done < /tmp/lun_$NOM_NETAPP_$VOL
  cat /tmp/lun_$NOM_NETAPP_$VOL >>/tmp/rapport_$NOM_NETAPP.txt
done < /tmp/volumes_$NOM_NETAPP

clear
grep -v "Volume Filesystem" /tmp/rapport_$NOM_NETAPP.txt

rm /tmp/*_$NOM_NETAPP*
