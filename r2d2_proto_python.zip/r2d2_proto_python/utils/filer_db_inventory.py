#!/opt/UNS/VENV/VENV_CISCO/bin/python3
# -*- coding: utf-8 -*-
# Alimentation de la database

import os
import sys
import context
from datetime import datetime
###A remplacer par logger
from lib.utils.utils import perror
from lib.AppLogger import AppLogger

from config import Config
import argparse

def commandline_parser():
    p = argparse.ArgumentParser(description=os.path.basename( sys.argv[0] ))
    p.add_argument('-n','--nom',  type=str, help="Nom du filer",required=True)
    args=p.parse_args()
    return args

if __name__ == '__main__':
    myconfig = Config(os.path.abspath('..'))
    myLog=AppLogger(os.path.basename(__file__),myconfig.log)
    from lib.db.Inventaire import Inventaire

    from lib.SevenModeApi import SevenModeApi, NaError

    inventaire=Inventaire(myconfig.database_inventory)
    from lib.db.Referentiel import Referentiel
    ref = Referentiel(myconfig.referentiel_inventory)
    args=commandline_parser()
    fas=args.nom.upper()

    d = datetime.now()
    myLog.info( ("Debut %.2d:%.2d")%(d.hour,d.minute) )
    myLog.info("Suppression de la reference au filer %s dans l'inventaire"%fas)
    nb=inventaire.delete_filer(fas)
    if nb == None:
       nb = 0

    myLog.info(" %d ligne(s) supprimées"%nb)

    try:
        print(fas)
        myFiler=SevenModeApi(fas, myconfig.batch_user, myconfig.batch_passwd)
        vDict={}
        dictVol={}
        dicAggr={}
        myLog.info("Recuperation infos vfiler")
        vDict=myFiler.vfiler_list_info()
        myLog.info("Recuperation infos volumes")
        dictVol=myFiler.volume_listinfo()
        myLog.info("Recuperation infos Aggregat")
        dicAggr=myFiler.aggr_spaceinfo()
        myLog.info("Recuperation info ipspace")
        tabIpspace=myFiler.ipspace_list_info()
        for k in dicAggr.keys():
            myLog.info("rcuperation type de disque pour l'aggregat %s"%k)
            #print("Aggregat",k)
            dicAggr[k]["typeDisk"]=myFiler.aggr_get_disk_type(k)
                #print(k,dicAggr[k]["typeDisk"])

        myFiler=None
    except NaError as e:
        d = datetime.now()
        myLog.error(("%.2d%.2d-%.2d%.2d: [errno %s]= %s from %s")%(d.day,d.month,d.hour,d.minute,e.errno,e.message,e.function))
        exit()
    except Exception as e:
        d = datetime.now()
        perror(("%.2d%.2d-%.2d%.2d: [errno %s]")%(d.day,d.month,d.hour,d.minute,e.message))
        exit()
    myLog.info("debut insertion dans la bdd")
    for k in vDict.keys():
        inventaire.addVfiler(vDict[k]["name"],vDict[k]["status"],fas, vDict[k]["ip"],vDict[k]["ipspace"])

    for k in dictVol.keys():
        inventaire.addVolume(k,dictVol[k]["state"], dictVol[k]["owningVfiler"], fas,
                                 dictVol[k]["sizeTotal"], dictVol[k]["sizeUsed"],
                                 dictVol[k]["snapReserve"], dictVol[k]["containing-aggregate"]
         )
    for k in dicAggr.keys():
        inventaire.addAggregat(k, fas, dicAggr[k]["aggrSizeNominal"],
                                dicAggr[k]["aggrSizeUsed"],
                                dicAggr[k]["volProvisionning"],
                                dicAggr[k]["typeDisk"])

    for t in tabIpspace:
        inventaire.addInterface(name=t[1],ipspace=t[0],filer=fas,vlan=t[2])

    d = datetime.now()
    myLog.info( ("Fin %.2d:%.2d")%(d.hour,d.minute) )
