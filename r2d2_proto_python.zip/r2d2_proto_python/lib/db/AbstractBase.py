# -*- coding: utf-8 -*-
from sqlalchemy import Column
from sqlalchemy.types import Unicode, Integer, DateTime, String
from sqlalchemy import desc
from sqlalchemy.sql import func

from lib.db import Base,create_engine,sessionmaker


__all__ = ['AbstractBase','decorate_session']

def decorate_session(func):
    # print("####")
    #print (u"Je suis dans la fonction 'decorate' et je décore '%s.'" % func.__name__)
    def wrapper(self,*args, **kwargs):
        result=None
        try:

            self.session_init()
            # print(func.__name__)
            result=func(self, *args, **kwargs)
            #print("commit")
            self.session.commit()
        except Exception as e:
            print(e.args)
            print("rollback")
            self.session.rollback()
        finally:
            self.session_close()
            return result
            # print("close")
    return wrapper


class AbstractBase(object):
    """ Accès base de données
    """
    def __init__(self,bddFile):
        self.engine = create_engine('sqlite:///' + bddFile)
        Base.metadata.bind = self.engine
        self.DBSession = sessionmaker(bind=self.engine)
        self.session = None

    def session_init(self):
        if not self.session:
            self.session = self.DBSession()

    def session_close(self):
        if self.session:
            self.session.close()
            self.session=None

    def session_rollback(self):
        if self.session:
            self.session_rollback()

    def session_commit(self):
        if self.session:
            self.session.commit()

    def flush(self):
        # engine = create_engine('sqlite:///' + contexte.database_inventory)
        # Base.metadata.bind = engine
        # Truncate des tables avant mise à jour
        with self.engine.connect() as con:
            trans = con.begin()
            for table in reversed(Base.metadata.sorted_tables):
                print("table delete "+table.name)
                con.execute(table.delete())
            trans.commit()

    @decorate_session
    def select_all(self, table):
        #self.session_init()
        aQuery = self.session.query(table)
        #self.session_close()
        return [u.__dict__ for u in aQuery.all()]

    @decorate_session
    def delete_by_id(self, table, id):
        """
        :param table:
        :param id:
        :return:
        """
        enregtosuppress = self.session.query(table).filter_by(id=id).first()
        self.session.delete(enregtosuppress)

    def drop(self, table):
        return table.__table__.drop(self.engine, checkfirst=True)

    def create(self, table):
        return table.__table__.create(self.engine, checkfirst=True)