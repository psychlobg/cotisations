#! /bin/bash

#for baie in BFSTOE50 BFSTOE51 BFSTOE63 BFSTOE65 IBSTOE52 IBSTOE53 IBSTOE58 IBSTOE59 IBSTOE66 IBSTOE68
for baie in IBSTOE44 IBSTOE46
do
	echo "Inventaire ${baie}A"
	./filer_db_inventory.py -n ${baie}
done
 
