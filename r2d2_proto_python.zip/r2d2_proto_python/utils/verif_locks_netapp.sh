#!/bin/sh
###########################################################
# Fichier       :                                         #
# Objet         : Historisation des locks netapp          #
###########################################################


DATE=`date +"%Y%m%d"`
REP="/opt/UNS/NETAPP/r2d2_proto/utils"
HISTO="/log/app/R2D2/locks"
rm $HISTO/locks_netapp_${DATE}.txt

cd $REP
./ls_db_inventory.py | grep running |  awk -F"running" ' { print $2 } ' | sed 's/\t//g' | sed 's/  FAS/FAS/g' | cut -f2 -d" " | sort -u >/tmp/ctrl_netapp.txt

while read CTRL
do
  echo "Locks du controleur " $CTRL >>$HISTO/locks_netapp_${DATE}.txt
  ./nfslockCount.py -n $CTRL >>$HISTO/locks_netapp_${DATE}.txt
  echo " " >>$HISTO/locks_netapp_${DATE}.txt
done < /tmp/ctrl_netapp.txt

cd $HISTO
NB_EPUR=`find $HISTO/locks_netapp* -type f -mtime +60 | wc -l`
if [ $NB_EPUR -gt 0 ]
then
  find $HISTO/locks_netapp* -type f -mtime +60 | xargs -l1 rm
else
  echo "Pas de fichiers anciens a supprimer"
fi

rm /tmp/ctrl_netapp.txt
