# Configuration Home Directories NFS avec FreeIPA et Fallback Local

## Vue d'ensemble

Cette procédure configure des home directories NFS avec authentification Kerberos dans un environnement FreeIPA, avec fallback local transparent en cas d'indisponibilité du NAS.

## 1. Configuration SSSD Hook avec Fallback Local

### Script principal de gestion des homes
```bash
#!/bin/bash
# /usr/local/bin/dynamic-home.sh
USER=$1
EXPECTED_HOME="/home/$USER"
LOCAL_FALLBACK="/tmp/users/local_home_$USER"
NFS_HOME="nas:/vol/home/$USER"

# Test rapide de disponibilité NFS (timeout court)
timeout 10 mount -t nfs4 -o sec=krb5p,soft,timeo=30 "$NFS_HOME" /mnt/nfs-test 2>/dev/null
if [ $? -eq 0 ]; then
    umount /mnt/nfs-test 2>/dev/null
    # NAS disponible, laisser autofs gérer normalement
    echo "$EXPECTED_HOME"
else
    # NAS indisponible, créer fallback local transparent
    mkdir -p "$LOCAL_FALLBACK"
    chown "$USER:$USER" "$LOCAL_FALLBACK"
    chmod 700 "$LOCAL_FALLBACK"
    
    # Copier squelette utilisateur si première création
    if [ ! -f "$LOCAL_FALLBACK/.bashrc" ]; then
        cp -r /etc/skel/. "$LOCAL_FALLBACK/"
        chown -R "$USER:$USER" "$LOCAL_FALLBACK"
    fi
    
    # Créer bind mount transparent vers le chemin attendu
    mkdir -p "$EXPECTED_HOME"
    mount --bind "$LOCAL_FALLBACK" "$EXPECTED_HOME"
    
    # Logger pour monitoring
    logger -t home-fallback "User $USER using local fallback: $LOCAL_FALLBACK"
    
    echo "$EXPECTED_HOME"
fi
```

### Script de nettoyage au logout
```bash
#!/bin/bash
# /usr/local/bin/cleanup-home.sh
USER=$1
EXPECTED_HOME="/home/$USER"
LOCAL_FALLBACK="/tmp/users/local_home_$USER"

# Vérifier si c'est un bind mount vers le fallback local
if mountpoint -q "$EXPECTED_HOME"; then
    MOUNT_TARGET=$(findmnt -rno SOURCE "$EXPECTED_HOME")
    if [[ "$MOUNT_TARGET" == "$LOCAL_FALLBACK" ]]; then
        # Démonter le bind mount
        umount "$EXPECTED_HOME"
        
        # Optionnel: archiver les données locales
        tar -czf "/tmp/users/backup_${USER}_$(date +%Y%m%d_%H%M%S).tar.gz" -C "$LOCAL_FALLBACK" .
        
        logger -t home-cleanup "Local fallback unmounted for $USER"
    fi
fi
```

### Configuration SSSD
```ini
# /etc/sssd/sssd.conf
[domain/example.com]
override_homedir = /usr/local/bin/dynamic-home.sh %u
```

## 2. Configuration AutoFS pour NFS

### Auto.master
```bash
# /etc/auto.master
/home /etc/auto.home --timeout=300
```

### Auto.home avec wildcard
```bash
# /etc/auto.home
* -fstype=nfs4,sec=krb5p,soft,timeo=100,retrans=3 netapp-svm:/vol/home/&
```

### Configuration FreeIPA AutoMount
```bash
# Créer la location automount
ipa automountlocation-add default

# Créer la map pour les home directories
ipa automountmap-add default auto.home

# Ajouter la map au master
ipa automountkey-add default auto.master --key /home --info "auto.home --timeout=60"

# Configuration dynamique avec wildcard
ipa automountkey-add default auto.home --key '*' --info '-fstype=nfs4,sec=krb5p,vers=4 netapp-svm.domain.com:/vol/home/&'
```

## 3. Configuration NetApp

### Authentification Kerberos
```bash
# Créer le realm Kerberos
vserver nfs kerberos realm create -vserver <svm> -realm DOMAIN.COM \
  -kdc-ip <freeipa-server> -admin-server-ip <freeipa-server>

# Configuration export policy sécurisée
vserver export-policy rule create -vserver <svm> -policyname home_dirs \
  -clientmatch <subnet> -rorule krb5p -rwrule krb5p -anon 65534 \
  -superuser krb5p
```

### Service Principal NetApp dans FreeIPA
```bash
# Créer le service principal pour le NetApp SVM
ipa service-add nfs/netapp-svm.domain.com

# Générer et récupérer le keytab
ipa-getkeytab -s freeipa-server.domain.com -p nfs/netapp-svm.domain.com \
  -k /tmp/netapp.keytab

# Installer le keytab sur le NetApp (procédure spécifique au modèle)
```

## 4. Création Automatique des Dossiers dans FreeIPA

### Hook FreeIPA pour création automatique
```bash
#!/bin/bash
# /usr/local/bin/freeipa-user-creation-hook.sh
# À installer sur le serveur FreeIPA

USER=$1
NETAPP_SVM="netapp-svm.domain.com"
NETAPP_USER="admin"

# Création via API REST NetApp
create_user_qtree() {
    curl -X POST "https://$NETAPP_SVM/api/storage/qtrees" \
      -u "$NETAPP_USER" \
      -H "Content-Type: application/json" \
      -k \
      -d "{
        \"svm\": {\"name\": \"svm1\"},
        \"volume\": {\"name\": \"home_vol\"},
        \"name\": \"$USER\",
        \"security_style\": \"unix\",
        \"unix_permissions\": 448
      }"
}

# Alternative via SSH (si API non disponible)
create_user_directory_ssh() {
    ssh root@$NETAPP_SVM "
      mkdir -p /vol/home_vol/$USER
      chmod 700 /vol/home_vol/$USER
      chown $USER:$USER /vol/home_vol/$USER
    "
}

# Tenter création
if ! create_user_qtree; then
    create_user_directory_ssh
fi

logger -t freeipa-hook "Home directory created for user $USER"
```

### Plugin FreeIPA (optionnel - plus avancé)
```python
# /usr/lib/python3.x/site-packages/ipalib/plugins/user_home_creation.py
from ipalib import api
from ipalib.plugable import Registry
from ipalib.plugins.user import user_add
import subprocess

register = Registry()

@register()
class user_add_with_home(user_add):
    def post_callback(self, ldap, dn, entry_attrs, *keys, **options):
        # Appeler le script de création après création utilisateur
        username = keys[0]
        try:
            subprocess.run(['/usr/local/bin/freeipa-user-creation-hook.sh', username], 
                          check=True, timeout=30)
        except subprocess.CalledProcessError:
            api.log.warning(f"Failed to create home directory for {username}")
        
        return dn
```

## 5. Synchronisation des Données Locales

### Script de synchronisation automatique
```bash
#!/bin/bash
# /usr/local/bin/sync-home.sh
USER=$1
LOCAL_BACKUP="/tmp/users/local_home_$USER"
NAS_HOME="nas:/vol/home/$USER"
SYNC_MOUNT="/tmp/users/sync_$USER"

# Vérifier si on a des données locales à synchroniser
if [ -d "$LOCAL_BACKUP" ] && [ "$(ls -A $LOCAL_BACKUP 2>/dev/null)" ]; then
    # Tenter montage NAS pour sync
    mkdir -p "$SYNC_MOUNT"
    if timeout 30 mount -t nfs4 -o sec=krb5p "$NAS_HOME" "$SYNC_MOUNT"; then
        logger -t home-sync "Starting sync for $USER: local → NAS"
        
        # Synchronisation avec rsync
        rsync -av --update "$LOCAL_BACKUP/" "$SYNC_MOUNT/"
        
        if [ $? -eq 0 ]; then
            logger -t home-sync "Sync completed for $USER"
            rm -rf "$LOCAL_BACKUP"
        else
            logger -t home-sync "Sync failed for $USER, keeping local data"
        fi
        
        umount "$SYNC_MOUNT"
    else
        logger -t home-sync "NAS still unavailable for $USER"
    fi
fi
```

### Synchronisation périodique (cron)
```bash
# /etc/cron.d/home-sync
*/15 * * * * root /usr/local/bin/periodic-sync.sh

# /usr/local/bin/periodic-sync.sh
#!/bin/bash
for USER_DIR in /tmp/users/local_home_*; do
    if [ -d "$USER_DIR" ]; then
        USER=$(basename "$USER_DIR" | sed 's/local_home_//')
        
        # Synchroniser si utilisateur déconnecté
        if ! who | grep -q "^$USER "; then
            /usr/local/bin/sync-home.sh "$USER"
        fi
    fi
done
```

## 6. Monitoring et Maintenance

### Script de monitoring
```bash
#!/bin/bash
# /usr/local/bin/monitor-homes.sh

# Vérifier les fallbacks actifs
echo "=== Fallbacks locaux actifs ==="
for dir in /tmp/users/local_home_*; do
    if [ -d "$dir" ]; then
        user=$(basename "$dir" | sed 's/local_home_//')
        size=$(du -sh "$dir" | cut -f1)
        echo "$user: $size"
    fi
done

# Vérifier les montages NFS
echo "=== Montages NFS homes ==="
mount | grep ":/vol/home" | wc -l
echo "montages actifs"

# Alerter si trop de données locales
TOTAL_SIZE=$(du -sb /tmp/users/local_home_* 2>/dev/null | awk '{sum+=$1} END {print sum/1024/1024}')
if [ "$TOTAL_SIZE" -gt 500 ]; then  # 500MB
    logger -t home-monitor "WARNING: ${TOTAL_SIZE}MB of unsynced local data"
fi
```

## 7. Installation et Permissions

### Rendre les scripts exécutables
```bash
chmod +x /usr/local/bin/dynamic-home.sh
chmod +x /usr/local/bin/cleanup-home.sh
chmod +x /usr/local/bin/sync-home.sh
chmod +x /usr/local/bin/periodic-sync.sh
chmod +x /usr/local/bin/monitor-homes.sh
```

### Créer les répertoires nécessaires
```bash
mkdir -p /tmp/users
chmod 755 /tmp/users
mkdir -p /mnt/nfs-test
```

### Configuration SELinux (si activé)
```bash
# Autoriser les bind mounts pour SSSD
setsebool -P use_nfs_home_dirs on
setsebool -P authlogin_nsswitch_use_ldap on
```

## Résumé des Avantages

- **Transparence totale** : L'utilisateur voit toujours `/home/$USER`
- **Résilience** : Connexion possible même si NAS indisponible
- **Automatisation** : Création automatique des dossiers NAS
- **Récupération** : Synchronisation automatique des données locales
- **Monitoring** : Logs et alertes pour supervision
- **Sécurité** : Authentification Kerberos de bout en bout