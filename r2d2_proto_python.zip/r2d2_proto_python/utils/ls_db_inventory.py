#!/opt/UNS/VENV/VENV_CISCO/bin/python3
# -*- coding: utf-8 -*-

import os
import sys
import context
import datetime
from lib.utils.utils import perror

from config import Config

if __name__ == '__main__':
    myconfig = Config(os.path.abspath('..'))
    from lib.db import Base,create_engine,sessionmaker
    from lib.db.TablesInventaire import VfilerTable,VolumeTable
    from lib.db.Inventaire import Inventaire
    from lib.SevenModeApi import SevenModeApi, NaError
    inventaire=Inventaire(myconfig.database_inventory)
    result=inventaire.listAllVolumes()
    print("# liste des volumes stockés")
    for r in result:
        print( ("%30s \t%s \t%12s \t%8s \t%4d \t%4d \t%4d \t%s")%
               (r["name"],r["state"], r["owningVfiler"], r["filer"],
                r["sizeTotal"], r["sizeUsed"],r["snapReserve"], r["aggregate"])
               )
    result=inventaire.listAllVfiler()
    print("# liste des vfilers")
    for r in result:
        print( ("%14s \t%10s \t%8s \t%16s \t%8s ")%
               (r["name"],r["status"], r["filer"], r["ip"], r["ipspace"])
               )
