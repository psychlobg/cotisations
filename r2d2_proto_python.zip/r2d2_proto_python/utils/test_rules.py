#!/opt/UNS/VENV/VENV_CISCO/bin/python3
# -*- coding: utf-8 -*-

import os
import sys
import context
import datetime
from lib.utils.utils import perror

from config import Config
import argparse

def commandline_parser():
    p = argparse.ArgumentParser(description=os.path.basename( sys.argv[0] ))
    p.add_argument('-n','--nom',  type=str, help="Nom du vfiler",required=True)
    p.add_argument('-c','--client', type=str,
                   help="Nom du SI. (BPCEIT|BPCESA|EQX|MYSYS|NATIXIS)",required=True)
    p.add_argument('-e','--environnement', type=str, help="Environnement applicatif (PRD|INT|MAQ|GDCTECH)",required=True)


    args=p.parse_args()
    print(args)
    for k in args.__dict__:
        if args.__dict__[k] is not None and isinstance(args.__dict__[k],str):
            args.__dict__[k]=args.__dict__[k].upper()
    print(args)



    return args


if __name__ == '__main__':
    myconfig = Config(os.path.abspath('..'))

    ars=commandline_parser()

