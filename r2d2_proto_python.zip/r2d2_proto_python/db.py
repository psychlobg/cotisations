
from config import Config
contexte=Config()

print(contexte.base_dir)