#!/opt/UNS/VENV/VENV_CISCO/bin/python3
# -*- coding: utf-8 -*-
# Alimentation de la database

import os
import sys
import context
from datetime import datetime
###A remplacer par logger
from lib.utils.utils import perror
from lib.AppLogger import AppLogger

from config import Config
import argparse

def commandline_parser():
    p = argparse.ArgumentParser(description=os.path.basename( sys.argv[0] ))
    p.add_argument('-n','--nom',  type=str, help="Nom du filer",required=True)
    args=p.parse_args()
    return args

if __name__ == '__main__':
    myconfig = Config(os.path.abspath('..'))
    myLog=AppLogger(os.path.basename(__file__),myconfig.log)
    from lib.db.Inventaire import Inventaire

    from lib.SevenModeApi import SevenModeApi, NaError

    inventaire=Inventaire(myconfig.database_inventory)
    from lib.db.Referentiel import Referentiel
    ref = Referentiel(myconfig.referentiel_inventory)
    args=commandline_parser()
    fas=args.nom

    d = datetime.now()
    myLog.info( ("Debut %.2d:%.2d")%(d.hour,d.minute) )
    myLog.info("Suppression de la reference au filer %s dans l'inventaire"%fas)
    nb=inventaire.delete_filer(fas)
