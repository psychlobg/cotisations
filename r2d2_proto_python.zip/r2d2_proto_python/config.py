# -*- coding: utf-8 -*-
import sys
import logging
from logging import handlers
import os, os.path
import configparser
import json
from lib.Rules import RuleItce,RuleEQX
from lib.AppLogger import AppLogger

__all__ = ['Config']


class Config(object):
    def __init__(self,optionnal_dir=None):
        # First let's see where we're located
        if optionnal_dir is None:
            self.base_dir = os.path.normpath(os.path.abspath(os.path.curdir))
        else:
            self.base_dir = os.path.normpath(os.path.abspath(optionnal_dir))
        # We amend the system path so that Python can find
        # the application's modules.
        sys.path.insert(0, "/opt/UNS/VENV/VENV_CISCO/lib64/python3.3/site-packages/")
        sys.path.insert(0, self.base_dir)

        self.database_dir=self.base_dir+'/db/'
        self.conf_dir=self.base_dir+'/conf'

        #On alimente le dictionnaire de regles de creation de volumes / client
        self.rulesDirectory = os.path.normpath(self.base_dir+'/conf/volumes_rules/')
        self._all_rules={}
        for client in os.listdir(self.rulesDirectory):
            # on met le nom de la cle en majuscule
            KEY=client.upper()
            # celui du nom du repertoire en minuscule
            client=client.lower()
            clientDir=os.path.normpath(os.path.abspath(self.rulesDirectory+'/'+client))
            if os.path.isdir(clientDir):
                if client not in self._all_rules:
                    self._all_rules[KEY]={}
                for rule in os.listdir(clientDir):
                    rule=os.path.normpath(os.path.abspath(clientDir+'/'+rule))
                    # on recupere le nom de la regle
                    r=os.path.splitext(os.path.basename(rule))[0]
                    r=r.upper()

                    with open(rule,"r") as f:
                        self._all_rules[KEY][r]= json.load(f)

        try:
            self.__read_conf__(self.conf_dir+'/config.ini')


        except Exception as e:
            print(("Erreur avec le ficier de configuration : %s"%e.args))
            sys.exit(2)


    def __read_conf__(self,configfile):
        """
        :param configfile: fichier de configuration format ini
        :return:
        """
        config=configparser.ConfigParser()
        config.read(configfile)
        self.database_inventory=self.database_dir+config['DEFAULT']['DB_INVENTORY']
        self.referentiel_inventory=self.database_dir+config['DEFAULT']['DB_REFERENTIEL']
        self.liste_filers=list(map(lambda x: x.strip(),config['DEFAULT']['FILER'].split(",")))
        self.batch_user=config['DEFAULT']['BATCH_USER'].strip()
        self.batch_passwd=config['DEFAULT']['BATCH_PASSWORD'].strip()
        self.log=self.base_dir+ "/" + config['LOG']['file']

    def getRule(self,client, typeVol, application):
        """"
        retourne les regles de nommage, snapshot et deduplication a utiliser en fonction
        de la variable d'environnement positionnée
        :param client : nom du client (mysys|bpcesa|eqx)
        :param typeVol . type de volume. root/bur/nas sur le SI ITCE
        :return Un objet Rule spécifique au type de volume et au SI
        """
        myRule=None
        if client in "MYSYS":
            myRule=RuleItce(typeVol, self._all_rules[client])
        else:
            myRule=RuleEQX(typeVol,self._all_rules[client], application)
        return myRule
