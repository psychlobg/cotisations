#!/opt/UNS/VENV/VENV_CISCO/bin/python3
# -*- coding: utf-8 -*-
# Alimentation de la database

import os
import sys
import context
import datetime
###A remplacer par logger
from lib.utils.utils import perror

import argparse

from config import Config


if __name__ == '__main__':
    myconfig = Config(os.path.abspath('..'))
    from lib.db.Referentiel import Referentiel

    parser = argparse.ArgumentParser(description=os.path.basename( sys.argv[0] ))
    parser.add_argument('fichier', help="nom du fichier a charger en base", type=argparse.FileType('r'))
    args=parser.parse_args()
    liste=[]
    for line in args.fichier:
        #print(("# %s #")%line.strip())
        liste.append(line.strip())

    ref = Referentiel(myconfig.referentiel_inventory)
    # ref.dropPoolIpTable()
    # ref.createPoolIpTable()


    for i in range(2,len(liste)):
        #print(liste[i])
        tab=liste[i].split(";")
        if tab[0]:
            print("#",tab[0],tab[1])
            ref.addIP(ip=tab[0], netmask=tab[1], gateway=tab[2],
                              vlan=tab[3], campus=tab[4], vfiler = tab[5]
                         )
    print ("#fin chargement")


