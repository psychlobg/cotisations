# Configuration NetApp SVM avec FreeIPA et Authentification Kerberos

## Prérequis

- SVM NetApp configuré avec NFS
- Serveur FreeIPA fonctionnel
- Serveurs DNS séparés configurés
- Serveurs NTP séparés configurés
- Résolution DNS bidirectionnelle
- Synchronisation temporelle (écart max 5 minutes)

## Ports réseau requis

### NetApp → FreeIPA
- **88/TCP et 88/UDP** : Kerberos KDC (Key Distribution Center)
- **464/TCP et 464/UDP** : Kerberos Change/Set Password (kadmin)
- **749/TCP** : Kerberos Admin Server (kadmin)
- **389/TCP** : LDAP (optionnel si authentification LDAP)
- **636/TCP** : LDAPS (optionnel si LDAP sécurisé)

### Client NFS → NetApp
- **111/TCP et 111/UDP** : RPC Portmapper
- **2049/TCP et 2049/UDP** : NFS
- **4045/TCP et 4045/UDP** : NFS Lock Manager (NLM)
- **4046/TCP et 4046/UDP** : NFS Status Monitor (NSM)

### Client NFS → FreeIPA
- **88/TCP et 88/UDP** : Kerberos KDC
- **464/TCP et 464/UDP** : Kerberos Change Password

### NetApp → Serveurs HTTP/FTP (pour keytabs)
- **80/TCP** : HTTP
- **21/TCP** : FTP

## Configuration étape par étape

### 1. Configuration DNS sur le SVM
```bash
# Configurer les serveurs DNS séparés
vserver services name-service dns modify \
  -vserver <svm_name> \
  -domains <domain.com> \
  -name-servers <dns_server1>,<dns_server2>

# Vérifier la résolution DNS
vserver services name-service dns check -vserver <svm_name>
```

### 2. Configuration NTP
```bash
# Ajouter les serveurs NTP séparés
cluster time-service ntp server create -server <ntp_server1>
cluster time-service ntp server create -server <ntp_server2>

# Vérifier la synchronisation
cluster time-service ntp server show
cluster date show
```

### 3. Préparation côté FreeIPA

#### Création de l'hôte et des services
```bash
# Créer l'hôte NetApp dans FreeIPA
ipa host-add <svm_name>.<domain.com> --force

# Créer le service principal NFS
ipa service-add nfs/<svm_name>.<domain.com>

# Optionnel: Créer le service principal HOST
ipa service-add host/<svm_name>.<domain.com>
```

#### Génération des keytabs
```bash
# Générer le keytab pour NFS
ipa-getkeytab -s <freeipa_server> \
  -p nfs/<svm_name>.<domain.com> \
  -k /tmp/nfs-<svm_name>.keytab

# Générer le keytab pour HOST (optionnel)
ipa-getkeytab -s <freeipa_server> \
  -p host/<svm_name>.<domain.com> \
  -k /tmp/host-<svm_name>.keytab

# Combiner les keytabs
ktutil
ktutil: read_kt /tmp/nfs-<svm_name>.keytab
ktutil: read_kt /tmp/host-<svm_name>.keytab
ktutil: write_kt /tmp/combined-<svm_name>.keytab
ktutil: quit

# Vérifier le contenu
klist -k /tmp/combined-<svm_name>.keytab
```

#### Mise à disposition du keytab via HTTP
```bash
# Copier sur serveur web
sudo cp /tmp/combined-<svm_name>.keytab /var/www/html/keytabs/
sudo chmod 644 /var/www/html/keytabs/combined-<svm_name>.keytab

# Vérifier l'accessibilité
curl http://<web_server>/keytabs/combined-<svm_name>.keytab
```

### 4. Configuration Kerberos sur NetApp

#### Configuration du realm
```bash
# Créer la configuration Kerberos
vserver nfs kerberos config create \
  -vserver <svm_name> \
  -kdc-ip <freeipa_ip> \
  -kdc-port 88 \
  -kdc-vendor Other \
  -admin-server-ip <freeipa_ip> \
  -admin-server-port 749 \
  -default-realm <REALM.COM> \
  -clock-skew 5

# Vérifier la configuration
vserver nfs kerberos config show -vserver <svm_name>
```

#### Activation Kerberos sur l'interface avec keytab
```bash
# Activer Kerberos avec keytab via HTTP
vserver nfs kerberos interface enable \
  -vserver <svm_name> \
  -lif <lif_name> \
  -spn nfs/<svm_name>.<domain.com>@<REALM.COM> \
  -keytab-uri http://<web_server>/keytabs/combined-<svm_name>.keytab

# Exemple concret :
vserver nfs kerberos interface enable \
  -vserver svm01 \
  -lif nfs_data_lif \
  -spn nfs/svm01.example.com@EXAMPLE.COM \
  -keytab-uri http://webserver.example.com/keytabs/combined-svm01.keytab
```

### 5. Configuration alternative avec compte de service

#### Création du compte de service FreeIPA (si préféré)
```bash
# Créer l'utilisateur de service
ipa user-add netapp-service \
  --first="NetApp" \
  --last="Service Account" \
  --password

# Créer un rôle personnalisé
ipa role-add "NetApp Host Manager" \
  --desc="Role for NetApp SVM host management"

# Créer des privilèges personnalisés
ipa privilege-add "NetApp Host Creation" \
  --desc="Allow NetApp to create host entries"

# Ajouter les permissions nécessaires
ipa privilege-add-permission "NetApp Host Creation" \
  --permissions="System: Add Hosts"
ipa privilege-add-permission "NetApp Host Creation" \
  --permissions="System: Add Services"
ipa privilege-add-permission "NetApp Host Creation" \
  --permissions="System: Manage Host Keytab"

# Associer privilège au rôle
ipa role-add-privilege "NetApp Host Manager" \
  --privileges="NetApp Host Creation"

# Assigner le rôle à l'utilisateur
ipa role-add-member "NetApp Host Manager" --users=netapp-service
```

#### Activation avec compte de service
```bash
# Alternative avec compte de service
vserver nfs kerberos interface enable \
  -vserver <svm_name> \
  -lif <lif_name> \
  -spn nfs/<svm_name>.<domain.com>@<REALM.COM> \
  -admin-username netapp-service
# Le système demandera le mot de passe
```

### 6. Configuration LDAP (optionnel)
```bash
# Créer la configuration client LDAP
vserver services name-service ldap client create \
  -vserver <svm_name> \
  -client-config freeipa \
  -servers <freeipa_ip> \
  -schema RFC-2307 \
  -port 389 \
  -query-timeout 3 \
  -base-dn "dc=domain,dc=com" \
  -base-scope subtree \
  -referral-enabled false

# Activer LDAP pour l'authentification
vserver services name-service ns-switch modify \
  -vserver <svm_name> \
  -database passwd \
  -sources files,ldap

vserver services name-service ns-switch modify \
  -vserver <svm_name> \
  -database group \
  -sources files,ldap
```

### 7. Configuration des exports NFS avec Kerberos
```bash
# Créer une export-policy avec Kerberos
vserver export-policy rule create \
  -vserver <svm_name> \
  -policyname krb5_policy \
  -clientmatch <client_network> \
  -rorule krb5 \
  -rwrule krb5 \
  -superuser krb5 \
  -allow-suid true

# Pour authentification plus stricte (avec intégrité)
vserver export-policy rule create \
  -vserver <svm_name> \
  -policyname krb5i_policy \
  -clientmatch <client_network> \
  -rorule krb5i \
  -rwrule krb5i \
  -superuser krb5i \
  -allow-suid true

# Pour authentification avec chiffrement
vserver export-policy rule create \
  -vserver <svm_name> \
  -policyname krb5p_policy \
  -clientmatch <client_network> \
  -rorule krb5p \
  -rwrule krb5p \
  -superuser krb5p \
  -allow-suid true

# Appliquer la policy au volume
volume modify \
  -vserver <svm_name> \
  -volume <volume_name> \
  -policy krb5_policy
```

### 8. Configuration côté client Linux

#### Installation des packages
```bash
# RHEL/CentOS
yum install krb5-workstation nfs-utils

# Ubuntu/Debian  
apt-get install krb5-user nfs-common
```

#### Configuration Kerberos client
```bash
# Éditer /etc/krb5.conf
[libdefaults]
    default_realm = <REALM.COM>
    dns_lookup_realm = true
    dns_lookup_kdc = true
    ticket_lifetime = 24h
    renew_lifetime = 7d

[realms]
    <REALM.COM> = {
        kdc = <freeipa_server>:88
        admin_server = <freeipa_server>:749
    }

[domain_realm]
    .<domain.com> = <REALM.COM>
    <domain.com> = <REALM.COM>
```

#### Test d'authentification et montage
```bash
# Obtenir un ticket Kerberos
kinit <username>@<REALM.COM>

# Vérifier le ticket
klist

# Monter avec Kerberos
mount -t nfs4 -o sec=krb5 \
  <svm_name>.<domain.com>:/<path> /<mount_point>

# Exemples avec différents niveaux de sécurité :
# Authentification seule
mount -t nfs4 -o sec=krb5 <svm_name>:/<path> /<mount_point>

# Authentification + intégrité
mount -t nfs4 -o sec=krb5i <svm_name>:/<path> /<mount_point>

# Authentification + intégrité + chiffrement
mount -t nfs4 -o sec=krb5p <svm_name>:/<path> /<mount_point>
```

### 9. Vérifications et diagnostics
```bash
# Vérifier la configuration Kerberos NetApp
vserver nfs kerberos interface show -vserver <svm_name>
vserver nfs kerberos config show -vserver <svm_name>

# Test de connectivité Kerberos
vserver nfs kerberos config test -vserver <svm_name>

# Vérifier les export-policies
vserver export-policy rule show -vserver <svm_name>

# Vérifier l'état NFS
vserver nfs show -vserver <svm_name>

# Logs utiles pour le dépannage
event log show -messagename "*kerberos*"
event log show -messagename "*nfs*"
```

### 10. Dépannage courant

#### Problèmes de synchronisation temporelle
```bash
# Vérifier l'heure sur NetApp
cluster date show

# Vérifier l'écart avec FreeIPA
# L'écart doit être < 5 minutes
```

#### Problèmes de résolution DNS
```bash
# Tester la résolution DNS
vserver services name-service dns check -vserver <svm_name>

# Vérifier la résolution inverse
nslookup <svm_ip>
```

#### Problèmes de keytab
```bash
# Vérifier l'accessibilité du keytab
curl -I http://<web_server>/keytabs/combined-<svm_name>.keytab

# Régénérer le keytab si nécessaire
ipa-getkeytab -s <freeipa_server> \
  -p nfs/<svm_name>.<domain.com> \
  -k /tmp/new-keytab.keytab
```

## Notes importantes

### Pourquoi cette limitation pour l'upload local ?
- **Sécurité** : NetApp ne permet pas le stockage direct de keytabs sur le système pour éviter les risques de sécurité
- **Architecture** : Le processus nécessite un accès réseau pour valider et récupérer le keytab
- **Temporaire** : Le keytab n'est nécessaire que pendant la phase de configuration initiale

### Avantages de HTTPS
- **Chiffrement** : Le keytab est transféré de manière chiffrée
- **Intégrité** : Protection contre l'altération pendant le transfert
- **Authentification** : Vérification de l'identité du serveur (avec certificat valide)

- Le nom du SVM doit être résolvable en DNS
- Le realm Kerberos doit être en MAJUSCULES
- Les horloges doivent être synchronisées (tolérance max 5 minutes)
- Tester d'abord avec `sec=krb5`, puis `sec=krb5i` ou `sec=krb5p` selon les besoins
- Les keytabs doivent être accessibles via HTTP/FTP pendant la configuration
- Après configuration, les keytabs peuvent être supprimés du serveur web

## Sécurité des niveaux Kerberos

- **krb5** : Authentification uniquement
- **krb5i** : Authentification + vérification d'intégrité
- **krb5p** : Authentification + intégrité + chiffrement (le plus sécurisé)

## Exemples concrets

### Exemple complet avec domaine example.com
```bash
# FreeIPA
ipa host-add svm01.example.com --force
ipa service-add nfs/svm01.example.com
ipa-getkeytab -s ipa.example.com -p nfs/svm01.example.com -k /tmp/svm01.keytab

# NetApp
vserver nfs kerberos config create -vserver svm01 -kdc-ip 192.168.1.10 -admin-server-ip 192.168.1.10 -default-realm EXAMPLE.COM
vserver nfs kerberos interface enable -vserver svm01 -lif data_lif -spn nfs/svm01.example.com@EXAMPLE.COM -keytab-uri http://webserver.example.com/svm01.keytab

# Client
kinit user@EXAMPLE.COM
mount -t nfs4 -o sec=krb5 svm01.example.com:/vol1 /mnt/nfs
```