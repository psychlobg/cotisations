# -*- coding: utf-8 -*-
from sqlalchemy import Column
from sqlalchemy.types import Unicode, Integer, DateTime, String
from sqlalchemy import desc
from sqlalchemy.sql import func

from lib.db import Base

__all__ = ['VfilerTable','VolumeTable','AggregatTable','InterfaceTable']

class VfilerTable(Base):
    """ Table VFILER pour la base de données Inventaire. S'appuie sur SQLAlchemy.
    """
    __tablename__ = 'vfiler'
    # Here we define columns for the table person
    # Notice that each column is also a normal Python instance attribute.
    # uuid = Column(String(128), nullable=False,primary_key=True)
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(64), nullable=False)
    status = Column(String(32), nullable=False)
    filer = Column(String(32), nullable=False)
    ip = Column(String(128), nullable=False)
    ipspace = Column(String(64), nullable=False)

class VolumeTable(Base):
    """ Table Volumes pour la base de données Inventaire. S'appuie sur SQLAlchemy.
    """
    __tablename__ = 'volumes'
    # uuid = Column(String(128), nullable=False,primary_key=True)
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(128), nullable=False)
    state = Column(String(32), nullable=False)
    owningVfiler = Column(String(32), nullable=False)
    filer = Column(String(32), nullable=False)
    sizeTotal = Column(Integer, nullable=False)
    sizeUsed = Column(Integer, nullable=False)
    snapReserve = Column(Integer, nullable=False)
    aggregate = Column(Integer, nullable=False)


class InterfaceTable(Base):
    """
    Table aggregat pour bdd inventaire
    """
    __tablename__ = 'interfaces'
    # uuid = Column(String(128), nullable=False,primary_key=True)
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(128), nullable=False)
    ipspace = Column(String(64), nullable=False)
    filer  = Column(String(32), nullable=False)
    vlan = Column(Integer, nullable=False)

class AggregatTable(Base):
    """
    Table aggregat pour bdd inventaire
    """
    __tablename__ = 'aggregats'
    # uuid = Column(String(128), nullable=False,primary_key=True)
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(128), nullable=False)
    filer = Column(String(32), nullable=False)
    aggrSizeNominal = Column(Integer, nullable=False)
    # dict[aggrName]={'aggrSizeNominal':aggrSizeNominal,'aggrSizeUsed':aggrSizeUsed,'volProvisionning':volProvisionning}
    aggrSizeUsed = Column(Integer, nullable=False)
    volProvisionning = Column(Integer, nullable=False)
    typeDisk = Column(String(32), nullable=False)

