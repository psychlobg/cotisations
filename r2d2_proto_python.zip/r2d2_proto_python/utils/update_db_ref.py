#!/opt/UNS/VENV/VENV_CISCO/bin/python3
# -*- coding: utf-8 -*-

import os
import sys
import context
import datetime
from lib.utils.utils import perror

from config import Config

if __name__ == '__main__':
    myconfig = Config(os.path.abspath('..'))
    from lib.db.Referentiel import Referentiel

    ref = Referentiel(myconfig.referentiel_inventory)
    ref.associate_interface_with_vfiler(ip="126.199.156.106",vfiler="adresse rendu (myway prod)")
