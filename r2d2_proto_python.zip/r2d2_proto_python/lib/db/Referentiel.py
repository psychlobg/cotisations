# -*- coding: utf-8 -*-
from sqlalchemy import Column, or_
from sqlalchemy.types import Unicode, Integer, DateTime, String
from sqlalchemy import desc
from sqlalchemy.sql import func


from lib.db import Base,create_engine,sessionmaker
from .TablesReferentiel import RefFilerTable,RefDomainTable, RefCampusTable, RefPoolIpTable
from .AbstractBase import AbstractBase,decorate_session

__all__=['Referentiel']
class Referentiel(AbstractBase):
    """ Classe permettant d'attaquer la base Référentiel
    """
    def createFilerTable(self):
        self.create(RefFilerTable)

    def dropFilerTable(self):
        self.drop(RefFilerTable)

    def createDomainTable(self):
        self.create(RefDomainTable)

    def dropDomainTable(self):
        self.drop(RefDomainTable)

    def createPoolIpTable(self):
        self.create(RefPoolIpTable)

    def dropPoolIpTable(self):
        self.drop(RefPoolIpTable)

    @decorate_session
    def addDomain(self,name, campus ,client, environment, dns, user, password):
        """
        Ajoute un domaine de référence
        :param name: nom du domaine
        :param campus: son campus
        :param client: le client qui l'utilise
        :param environment: prod, maq, sie
        :param dns: liste des dns
        :param user: user pour l'inscription dans le domaine
        :param password: son password
        :return:
        """

        domain=RefDomainTable(name=name, campus=campus, client=client,
                            environment=environment, dns=dns,
                            user=user, password=password)
        self.session.add(domain)

    @decorate_session
    def addIP(self,ip, netmask ,gateway, vlan, campus, vfiler = None ):
        """
        Ajoute une IP à la table pool_ip
        :param ip:
        :param netmask:
        :param gateway:
        :param vlan:
        :param campus:
        :param vfiler: (None) par défaut
        :return:
        """

        poolip=RefPoolIpTable(ip=ip, netmask=netmask, gateway=gateway,
                              vlan=vlan, campus=campus, vfiler = vfiler
                            )
        self.session.add(poolip)

    def deleteId(self,id):
        self.delete_by_id(RefFilerTable,id)

    def addFiler(self,name,ip,site,client, environment, application, platine, gold, silver, bronze):
        """

        :param name: nom du controleur
        :param ip: son ip d'admin
        :param site: nom du datacenter
        :param client: le client (MySYS/IbP/BPCE-SA)
        :param environment: ALL/PROD/MAQ/INT
        :param application: BUR (bureautique) ou AUTRE
        :return:
        """

        self.session_init()
        filer=RefFilerTable(name=name, ip=ip, site=site, client=client,
                            environment=environment, application=application,
                            police_platine= platine, police_gold=gold, police_silver=silver, police_bronze=bronze)
        self.session.add(filer)
        self.session.commit()
        self.session_close()

    def listAllFiler(self):
        return self.select_all(RefFilerTable)

    def listPoolIP(self):
        return self.select_all(RefPoolIpTable)

    def createCampusTable(self):
        self.create(RefCampusTable)

    def dropCampusTable(self):
        self.drop(RefCampusTable)

    @decorate_session
    def addCampus(self,name, site ):
        """
        Ajoute un domaine de référence
        :param name: nom du campus
        :param site: la liste des sites qui le composent séparés par des virgules
        :return:
        """

        campus=RefCampusTable(name=name, site=site)
        self.session.add(campus)

    @decorate_session
    def get_disktype_from_police(self, filer, police ):
        police=police.lower()
        type_disk=None
        table=None
        if police == "platine":
            table=RefFilerTable.police_platine
        elif police == "gold":
            table=RefFilerTable.police_gold
        elif police == "silver":
            table=RefFilerTable.police_silver
        else:
            table=RefFilerTable.police_bronze
        type_disk = self.session.query(table).filter(RefFilerTable.name == filer).one()
        if type_disk:
            type_disk=type_disk[0]
        return type_disk

    @decorate_session
    def get_campus_from_filer(self,filer):
        s=self.session
        campus = None
        filer_site=s.query(RefFilerTable.site).filter(RefFilerTable.name == filer).one()
        if filer_site:
            filer_site='%'+filer_site[0]+'%'
            r=s.query(RefCampusTable.name).filter(RefCampusTable.site.like(filer_site)).one()
            if r:
                campus=r[0]
        return campus

    @decorate_session
    def get_free_ip(self, vlan, campus):
        """
        REcupere une ip libre
        :param vlan: nom du vlan
        :param campus: nom du cmapus
        :return: (ip, netmask, gtw) | (None, None, None)
        """
        ip=self.session.query(RefPoolIpTable.ip,RefPoolIpTable.netmask,RefPoolIpTable.gateway)\
            .filter(RefPoolIpTable.campus == campus, RefPoolIpTable.vlan == vlan, ( (RefPoolIpTable.vfiler == "") | (RefPoolIpTable.vfiler == None)) ).first()
        if ip:
            return ip
        else:
            return None, None, None


    @decorate_session
    def get_domain(self, name, campus, environment):
        """

        :param campus: nom du campus
        :param client:
        :param environment:
        :return: dns
        """
        name=name.lower()

        dns=self.session.query(RefDomainTable.dns)\
            .filter(RefDomainTable.name == name, RefDomainTable.campus == campus,RefDomainTable.environment == environment ).one()

        if dns:
            return dns[0].split(',')
        else:
            return None

    @decorate_session
    def associate_interface_with_vfiler(self, ip, vfiler):
        """
        Associe une IP à un vfiler
        :param ip:
        :param vfiler:
        :return:
        """
        row=self.session.query(RefPoolIpTable).filter(RefPoolIpTable.ip == ip).one()
        if row:
            #RefPoolIpTable.vfiler
            row.vfiler = vfiler
            self.session.add(row)
        return
    @decorate_session
    def get_gateway(self,ip):
        """

        :param ip:
        :return: gateway
        """
        row=self.session.query(RefPoolIpTable.gateway,RefPoolIpTable.netmask).filter(RefPoolIpTable.ip == ip).one()
        if row is not None:
            return row[0]
        else:
            return None











