#!/opt/UNS/VENV/VENV_CISCO/bin/python3

#

import sys,inspect,os
from math import floor,ceil,pow

from .NetApp.NaElement import *
from .NetApp.NaServer import *

import ssl

try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    # Legacy Python that doesn't verify HTTPS certificates by default
    pass
else:
    # Handle target environment that doesn't support HTTPS verification
    ssl._create_default_https_context = _create_unverified_https_context

__all__=['SevenModeApi', 'NaError']


class SevenModeApi(object):
    """ Enrobage de l'api Netapp
    """
    def __init__(self,fas,user,password):
        self.naserver=NaServer(fas, 1, 19)
        self.naserver.set_server_type("FILER")
        self.naserver.set_transport_type("HTTP")
        self.naserver.set_port(80)
        self.naserver.set_style("LOGIN")
        self.naserver.set_admin_user(user, password)
        self.filerName=fas
        self.log=None

    def set_vfiler_context(self,vfiler):
        self.naserver.set_vfiler(vfiler)

    def unset_vfiler_context(self):
        self.naserver.set_vfiler("")

    def setLogger(self,logger):
        """
        :param logger:  nom du Logger (object importlogging)
        :return:
        """
        self.log=logger

    def execute(self,api):
        """execute une api sur un filer
         Args :
          s (NaServer s). Object NaServer
          api (NaElement)
          Return :
          xo (NaElement)
        """

        if self.log : self.log.debug(api.sprintf())
        xo = self.naserver.invoke_elem(api)
        if self.log : self.log.debug(xo.sprintf())

        if (xo.results_status() == "failed") :
            try:
                callingFunction=inspect.stack()[1][3]
            except IndexError:
                callingFunction=inspect.stack()[0][3]
            raise NaError(xo.results_reason(),str(xo.results_errno()),callingFunction)
        return xo

    def systemcli(self,cmd):
        """
            permet de passer une commande comme si on était sur le prompt.
            a n'utiliser que quand l'équivalent en api n'existe pas
        :param cmd: commande à passer.
        :return:
        :raise NaError:
        """
        api = NaElement("system-cli")
        args= NaElement("args")
        for i in cmd.split():
            args.child_add_string("arg",i)
        api.child_add(args)
        return self.execute(api)

    def get_version(self):
        """Get Api version"""
        api = NaElement("system-get-version")
        xo=self.execute(api)
        return xo.child_get_string("version")

    def disk_get_type(self,name):
        """
        :param name:
        :return:
        """
        api = NaElement("disk-list-info")
        api.child_add_string("disk",name)
        xo=self.execute(api)
        return xo.child_get("disk-details").children_get()[0].child_get_string("disk-type")




    def aggr_get_disk_type(self, name):
        """
        :param name: nom de l aggregat
        :return: envoie la techno de disk d un aggregat
        """
        dict={}
        api = NaElement("aggr-list-info")
        api.child_add_string("aggregate",name)
        api.child_add_string("verbose","true")
        xo=self.execute(api)

        aggr = xo.child_get("aggregates").children_get()[0]
        plex=aggr.child_get("plexes").children_get()[0]
        #print (plex)
        disk=plex.child_get("raid-groups").children_get()[0].child_get("disks").children_get()[0].child_get_string("name")
        #print (disk)
        return self.disk_get_type(disk)


    def aggr_spaceinfo(self):
        """ aggrSpaceInfo
         Un truc intelligent a mettre
         Args :
         s (NaServer s). Object NaServer
         Returns:
           Renvoie un dictionnaire (de dictionnaire) du type
           dict[aggrName]={'aggrSizeNominal':aggrSizeNominal,'aggrSizeUsed':aggrSizeUsed,'volProvisionning':volProvisionning}
       """
        dict={}
        api = NaElement("aggr-space-list-info")
        xo=self.execute(api)
        aggrSpaceInfo = xo.child_get("aggregates")
        aggrListe=aggrSpaceInfo.children_get()
        for aggr in aggrListe:
            aggrName=aggr.child_get_string("aggregate-name")
            aggrSizeNominal=self.convert_to_unit(aggr.child_get_int("size-nominal"), 3)
            aggrSizeUsed=self.convert_to_unit(aggr.child_get_int("size-used"), 3)
            #pas utilisé, ne sempble pasprendre en compte le snapshot reserve et l'espace rééllement provisionné.
            aggrVolAllocated=self.convert_to_unit(aggr.child_get_int("size-volume-allocated"), 3)
            volProvisionning=0

            result=aggr.child_get("volumes")
            if ( result != None ):
                listevol=result.children_get()
                for vol in listevol:
                    (size,snapshot,sizeUsed)=self.volume_spaceinfo(vol.child_get_string("volume-name"))
                    volProvisionning += size + snapshot

            dict[aggrName]={'aggrSizeNominal':aggrSizeNominal,'aggrSizeUsed':aggrSizeUsed,'volProvisionning':volProvisionning}

        return dict

    # Qtree
    def qtree_security(self, qtree, mode, vfiler_context=None):
        """
            Change le mode de securité d'une qtree
        :param qtree: nom de la qtree (ou du volume)
        :param mode:  unix/ntfs ou mixed
        :param vfiler_context: Si la qtree est dans un vfiler, on indique le vfiler
        :return:
        :raise NaError:
        """
        if vfiler_context is not None:
            self.set_vfiler_context(vfiler_context)
        if "/vol" not in qtree:
            qtree="/vol/"+qtree
        cli="qtree security %s %s"%(qtree,mode)
        xo=self.systemcli(cli)
        if vfiler_context is not None:
            self.unset_vfiler_context()
        return xo.results_status()

    def qtree_create(self, volume_name, qtree, vfiler_context=None):
        """
            Change le mode de securité d'une qtree
        :param qtree: nom de la qtree (ou du volume)
        :param vfiler_context: Si la qtree est dans un vfiler, on indique le vfiler
        :return:
        :raise NaError:
        """
        if vfiler_context is not None:
            self.set_vfiler_context(vfiler_context)

        api = NaElement("qtree-create")
        api.child_add_string("qtree",qtree)
        api.child_add_string("volume",volume_name)
        xo=self.execute(api)
        if vfiler_context is not None:
            self.unset_vfiler_context()
        return xo.results_status()

    def cifs_shares_add(self, sharepath, sharename, vfiler_context):
        """

        :param sharepath:
        :param sharename:
        :param vfiler_context:
        :return:
        """
        if vfiler_context is not None:
            self.set_vfiler_context(vfiler_context)
        if "/vol/" not in sharepath:
            sharepath="/vol/"+sharepath

        api = NaElement("cifs-share-add")
        api.child_add_string("path", sharepath)
        api.child_add_string("share-name",sharename)
        xo=self.execute(api)
        if vfiler_context is not None:
            self.unset_vfiler_context()
        return xo.results_status()

    def cifs_stop(self,vfiler_name):
        """
        Arrête la couche cifs d'un vfiler
        :param vfiler_name:
        :return:
        """
        if vfiler_name is not None:
            self.set_vfiler_context(vfiler_name)
        api = NaElement("cifs-stop")
        xo=self.execute(api)
        if vfiler_name is not None:
            self.unset_vfiler_context()
        return xo.results_status()

    def cifs_share_list(self, vfiler_name):
        """
        Recupere les shares cifs d'un vfiler
        :param viler_name:
        :return dict = { share : path }
        """
        if vfiler_name is not None:
            self.set_vfiler_context(vfiler_name)
        api = NaElement("cifs-share-list-iter-start")
        xo=self.execute(api)
        dictShare={}
        record=xo.child_get_string("records")
        tag=xo.child_get_string("tag")
        # print(record,tag)
        api1 = NaElement("cifs-share-list-iter-next")
        api1.child_add_string("maximum",record)
        api1.child_add_string("tag",tag)
        xo=self.execute(api1)
        shareListInfo=xo.child_get("cifs-shares").children_get()
        for share in shareListInfo:
            share_name=share.child_get_string("share-name")
            path_name=share.child_get_string("mount-point")
            dictShare[share_name]=path_name

        # print(dictShare)
        api2 = NaElement("cifs-share-list-iter-end")
        api2.child_add_string("tag", tag)
        xo=self.execute(api2)

        if vfiler_name is not None:
            self.unset_vfiler_context()
        return dictShare

    def cifs_setup(self, vfiler_name, auth_type, domainname, login_user=None, login_password=None, ou=None ):
        """

        :param vfiler_name:
        :param auth_type:
        :param domainname:
        :param login_user:
        :param login_password:
        :param ou:
        :return:
        """
        if auth_type not in ["ad","workgroup"]:
            raise Exception("cifs_setup : auth_type %s non gere"%auth_type)

        if vfiler_name is not None:
            self.set_vfiler_context(vfiler_name)

        api = NaElement("cifs-setup-create-passwd-file")
        api.child_add_string("default-root-password","SDFq7hgqher5r")
        self.execute(api)

        api1 = NaElement("cifs-setup-create-group-file")
        self.execute(api1)

        api2 = NaElement("cifs-setup")
        api2.child_add_string("auth-type",auth_type)
        if auth_type is "ad":
            api2.child_add_string("login-password",login_password)
            api2.child_add_string("login-user",login_user)
            api2.child_add_string("ou-name",ou)

        api2.child_add_string("domain-name",domainname)
        api2.child_add_string("security-style","ntfs")
        api2.child_add_string("server-name",vfiler_name)
        xo=self.execute(api2)
        if vfiler_name is not None:
            self.unset_vfiler_context()
        return xo.results_status()

    def cifs_shares_add_rights(self,vfiler_context,sharename,username,rights):
        """
        :param sharename:
        :param vfiler_context:
        :return:
        """
        if vfiler_context is not None:
            self.set_vfiler_context(vfiler_context)
        api = NaElement("cifs-share-ace-set")
        api.child_add_string("access-rights",rights)
        api.child_add_string("share-name",sharename)
        api.child_add_string("user-name",username)
        xo=self.execute(api)
        if vfiler_context is not None:
            self.unset_vfiler_context()
        return xo.results_status()

    def cifs_shares_delete_rights(self,vfiler_context,sharename,username):
        """
        :param sharepath:
        :param sharename:
        :param vfiler_context:
        :return:
        """
        if vfiler_context is not None:
            self.set_vfiler_context(vfiler_context)
        api = NaElement("cifs-share-ace-delete")
        api.child_add_string("share-name",sharename)
        api.child_add_string("user-name",username)
        xo=self.execute(api)
        if vfiler_context is not None:
            self.unset_vfiler_context()
        return xo.results_status()


    def add_default_route(self,vfiler_name,gateway,ipspace):
        """

        :param vfiler_name:
        :param gateway:
        :return:
        """
        if vfiler_name is not None:
            self.set_vfiler_context(vfiler_name)

        api = NaElement("net-route-add")
        xi = NaElement("route-info")
        api.child_add(xi)

        xi.child_add_string("addr-family","af-inet")
        xi.child_add_string("creator","vfiler:"+vfiler_name)
        xi.child_add_string("destination","default")
        xi.child_add_string("ipspace-name",ipspace)
        xi.child_add_string("metric","1")
        xi.child_add_string("next-hop",gateway)
        xi.child_add_string("route-type","net")
        xo=None
        try:
            xo=self.execute(api)
        except NaError as e:
            if e.errno == "1010":
                self.log.warning("La route existe deja")
            else:
                raise e

        finally:
            if vfiler_name is not None:
                self.unset_vfiler_context()


    #VFILER
    def vfiler_add_storage(self, volume, vfiler):
        """
            ajoute un volume a un vfiler
        :param self:
        :param volume: nom du volume
        :param vfiler: nom du vfiler
        :return:
        :raise NaError:
        """
        api = NaElement("vfiler-add-storage")
        if "/vol/" not in volume:
            volume="/vol/"+volume
            api.child_add_string("storage-path", volume)
        api.child_add_string("vfiler", vfiler)
        return self.execute(api).results_status()

    def vfiler_drconfigure(self, adIpaddrs_info, aIpdns, dRemote_authent_info, dRemote_vfiler_location ):
        """

        :param adIpaddrs_info: tableau de dictionnaire
                adIpaddrs_info=[{"interface":if,"ip-address":ip,"netmask";netmask},...]
        :param aIpdns: tableau avec la liste de dns aIpdns=["ip1","ip2",..]
        :param dRemote_authent_info: dRemote_authent_info={"username":user,"password":password}
        :param dRemote_vfiler_location: dRemote_vfiler_location ={"filer":filer-source,"vfiler": vfiler-source}
        :return:
        """
        api = NaElement("vfiler-dr-configure")
        xi = NaElement("DNS-server-ipaddrs")
        api.child_add(xi)
        for ipdns in aIpdns:
            xi.child_add_string("ip-address",ipdns)

        xi1 = NaElement("ipaddrs")
        api.child_add(xi1)

        for ipinfo in adIpaddrs_info:
            xi2 = NaElement("ipaddr-info")
            xi1.child_add(xi2)
            for k in ipinfo.keys():
                xi2.child_add_string(k,ipinfo[k])

        xi3 = NaElement("remote-authentication-info")
        api.child_add(xi3)
        xi4 = NaElement("authentication-info")
        xi3.child_add(xi4)
        for k in dRemote_authent_info.keys():
            xi4.child_add_string(k,dRemote_authent_info[k])

        xi5 = NaElement("remote-vfiler-location")
        api.child_add(xi5)
        xi6 = NaElement("vfiler-location")
        xi5.child_add(xi6)
        for k in dRemote_vfiler_location.keys():
            xi6.child_add_string(k,dRemote_vfiler_location[k])

        api.child_add_string("use-secure-command-channel","true")
        api.child_add_string("is-synchronous","false")
        api.child_add_string("snapmirror-not-initialize","false")
        return self.execute(api).results_status()

    def vfiler_drresync(self, dRemote_authent_info, dRemote_vfiler_location ):
        """
        vfiler dr resync
        :param dRemote_authent_info: dRemote_authent_info={"username":user,"password":password}
        :param dRemote_vfiler_location: dRemote_vfiler_location ={"filer":filer-source,"vfiler": vfiler-source}
        :return:
        """

        api = NaElement("vfiler-dr-resync")
        api.child_add_string("is-synchronous","false")
        api.child_add_string("use-secure-command-channel","true")
        xi3 = NaElement("remote-authentication-info")
        api.child_add(xi3)
        xi4 = NaElement("authentication-info")
        xi3.child_add(xi4)
        for k in dRemote_authent_info.keys():
            xi4.child_add_string(k,dRemote_authent_info[k])

        xi5 = NaElement("remote-vfiler-location")
        api.child_add(xi5)
        xi6 = NaElement("vfiler-location")
        xi5.child_add(xi6)
        for k in dRemote_vfiler_location.keys():
            xi6.child_add_string(k,dRemote_vfiler_location[k])

        return self.execute(api).results_status()


    def vfiler_create(self, ipaddresses, ipspace, volumeroot, vfilerName):
        """
        :param ipaddresses: array. liste des IPs
        :param ipspace:  string. nom de l'ipspace
        :param volumeroot: string. nom du volume root
        :param vfilerName:  nom du vfiler
        :return: naException en cas d'erreur
        :raise NaError:
        """
        api = NaElement("vfiler-create")
        i = NaElement("vfiler-create")
        xi = NaElement("ip-addresses")
        api.child_add(xi)
        for ip in ipaddresses:
            xi.child_add_string("ip-address",ip)
        api.child_add_string("ipspace", ipspace)

        xi1 = NaElement("storage-units")
        api.child_add(xi1)

        if "/vol/" not in volumeroot:
            volumeroot="/vol/"+volumeroot
        xi1.child_add_string("storage-unit", volumeroot)
        api.child_add_string("vfiler", vfilerName)
        return self.execute(api).results_status()

    def vfiler_setup(self, vfilername,  ipbindings, dnsdomain, dnsservers, password):
        """
        :param vfilername: string
        :param ipbindings: liste de dictionary {"interface:": x, "ipadress":y, "netmask":z
        :param dnsdomain: string
        :param dnsservers: liste
        :param password. string
        :return: Exception NaError en cas de problem
        :raise NaError:
        """
        api = NaElement("vfiler-setup")
        api.child_add_string("dnsdomain",dnsdomain)

        xi = NaElement("dnsservers")
        api.child_add(xi)

        for dns in dnsservers:
            xi1 = NaElement("dnsserver-info")
            xi.child_add(xi1)
            xi1.child_add_string("ipaddress", dns)

        xi2 = NaElement("ipbindings")
        api.child_add(xi2)
        for info in ipbindings:
            xi3 = NaElement("ipbinding-info")
            xi2.child_add(xi3)
            xi3.child_add_string("interface",info["interface"])
            xi3.child_add_string("ipaddress",info["ipaddress"])
            xi3.child_add_string("netmask",info["netmask"])
        api.child_add_string("password",password)
        api.child_add_string("vfiler", vfilername)
        return self.execute(api).results_status()

    def vfiler_setup_ssh(self,vfiler_context):
        """
                mise en place du ssh
        :param vfiler_context: nom du vfiler.
        :return:
        """
        self.set_vfiler_context(vfiler_context)
        xo=self.systemcli("secureadmin setup -f -q ssh 768 512 768")
        return xo.results_status()

    def vfiler_enable_httpd_admin(self,vfiler_context):
        """
        A   ctive l admin via httpd.
        :param vfiler_context: nom du vfiler
        :return:
        :raise NaError:
        """
        self.set_vfiler_context(vfiler_context)
        xo=self.systemcli("options httpd.admin.enable on")
        return xo.results_status()

    def vfiler_get_status(self, vfilerName):
        """Renvoie le statut du vfiler"""
        api = NaElement("vfiler-get-status")
        api.child_add_string("vfiler",vfilerName)
        xo=self.execute(api)
        return xo.child_get_string("status")

    def vfiler_list_info(self, vfilerName=None):
        """
            Renvoie un dictionnaire comprenant les infos sur les vfilers présents sur le controleur
        :param vfilerName: nom du vfiler.
        :return vfilerDict: [name]={"uuid":uuid,'name':name,'status':statut,'ip':ipaddress,'ipspace':ipspace}
        :raise NaError:
        """
        api = NaElement("vfiler-list-info")
        if vfilerName is not None:
            api.child_add_string("vfiler",vfilerName)

        xo=self.execute(api)
        vfilerListInfo=xo.child_get("vfilers").children_get()
        vfilerDict={}
        for vfiler in vfilerListInfo:
            name=vfiler.child_get_string("name")
            #if (name == "vfiler0") : continue
            #uuid=vfiler.child_get_string("uuid")
            #le uuid fourni n'est pas unique. On peut le retrouver sur differents  filers.
            # utilsation name + filer
            #uuid=self.filerName+"_"+name
            status=self.vfiler_get_status(name)
            ipspace=vfiler.child_get_string("ipspace")
            #print("Ipspace", ipspace)
            ipaddress=""
            for i  in vfiler.child_get("vfnets").children_get():
                ipaddress+=i.child_get_string("ipaddress")+" "
            vfilerDict[name]={'name':name,'status':status,'ip':ipaddress,'ipspace':ipspace}

        return vfilerDict

    def vfiler_get_volume_root_name(self, vfiler=None):
        """
            Retourne le nom du volume root du vfiler
        :param vfiler:  nom du vfiler
        :return: string. nom du volume
        :raise NaError:
        """
        if vfiler:
            self.set_vfiler_context(vfiler)
        api=NaElement("volume-get-root-name")
        xo=self.execute(api)
        v=xo.child_get_string("volume")
        self.unset_vfiler_context()
        return v

    #VOLUME#
    def volume_spaceinfo(self,volname):
        """ volumeSpaceInfo
        recupere la taille du volume et le snapshot reserve
        Args :
        s (NaServer s). Object NaServer
        volname (string). volume a interrgoer
        Renvoie un tupple (taille du volume, taille du snapshot) en Gb
       """
        #api space-info pas disponible pour 8.1.4
        api = NaElement("volume-list-info")
        api.child_add_string("volume",volname)
        xo=self.execute(api)
        result=xo.child_get("volumes")
        vol=result.children_get()
        volumeSize=self.convert_to_unit(vol[0].child_get_int("size-total"), 3)
        totalUsed=self.convert_to_unit(vol[0].child_get_int("size-used"), 3)
        volumeSnapshotReserve=0
        try:
            volumeSnapshotReserve=self.volume_get_snapshotreserve((volname))
        except:
            #cs ou le volume passe offline durant une vacation snapmirror
            volumeSnapshotReserve=0
        finally:
            return volumeSize,volumeSnapshotReserve,totalUsed

    def volume_state(self,volname):
        """ volumeState
        recupere le statut du volume
        Args :
        s (NaServer s). Object NaServer
        volname (string). volume a interrgoer
        Return :
        status (string)
        """
        api = NaElement("volume-list-info")
        api.child_add_string("volume",volname)
        xo=self.execute(api)
        return xo.child_get("volumes").child_get("volume-info").child_get_string("state")

    def volume_get_snapshotreserve(self,vol):
        """Renvoie la taille du snapshot reserve en Gb"""
        api = NaElement("snapshot-get-reserve")
        api.child_add_string("volume",vol)
        xo=self.execute(api)
        result = xo.child_get_int("blocks-reserved");
        # le resultat est en block de 1024
        return self.convert_to_unit(result, 2)

    def volume_getrootname(self):
        """volume_getrootname(s)
        Renvoie le nom du volume root du filer
        Args :
       s (NaServer s). Object NaServer
        """
        api = NaElement("volume-get-root-name")
        xo=self.execute(api)
        return xo.child_get_string("volume")

    def volume_snapmirror_status(self, volName):
        """
        Renvoie true le volume est la destination du snapmirror
        :param volName: nom du volume
        :return: { 'is-source' : '[true|false]', 'is-destination' : '[true|false]' }
        """
        dico={}
        try:
           api = NaElement("snapmirror-get-volume-status")
           api.child_add_string("volume",volName)
           xo=self.execute(api)
           dico['is-source']=xo.child_get_string("is-source") 
           dico['is-destination']=xo.child_get_string("is-destination")
        except:
        #pas de license snapmirrior
           dico['is-source']='false'
           dico['is-destination']='false'
        return dico

    def volume_listinfo(self,volName=None):
        """Renvoie les infos d'un volume sous forme de dictionnaire
        dictVol[name]  = {'state':state,'owningVfiler':owningVfiler,'sizeTotal':sizeTotal,'sizeUsed':sizeUsed,'snapReserve':snapReserve}
        """
        api = NaElement("volume-list-info")
        if volName is not None:
            api.child_add_string("volume",volName)
        xo=self.execute(api)
        volListInfo=xo.child_get("volumes").children_get()
        dictVol={}
        for vol in volListInfo:
            name=vol.child_get_string("name")
            #uuid=vol.child_get_string("uuid")
            #le uuid fourni n'est pas unique. On peut le retrouver sur differents  filers.
            # utilsation name + filer
            #uuid=self.filerName+"_"+name
            state=vol.child_get_string("state")
            owningVfiler=vol.child_get_string("owning-vfiler")
            containingAggr=vol.child_get_string("containing-aggregate")

            #Cas ou le volume passe offline pendant le script (ex snapmirror)
            try:
                (sizeTotal,snapReserve,sizeUsed)=self.volume_spaceinfo(name)
                snapmirror_status=self.volume_snapmirror_status(name)
                isdest=snapmirror_status["is-destination"] 
                issource=snapmirror_status["is-source"]
            except:
                isdest='true'
                issource='false'
                (sizeTotal,snapReserve,sizeUsed)=(0,0,0)
            dictVol[name]  = {'state':state,'owningVfiler':owningVfiler,'sizeTotal':sizeTotal,
                              'sizeUsed':sizeUsed,'snapReserve':snapReserve,
                              'containing-aggregate':containingAggr,
                              'is-snapmirror-destination': isdest,
                              'is-snapmirror-source': issource}
        return dictVol

    def volume_create(self,volName,aggrName,size):
        api = NaElement("volume-create")
        api.child_add_string("containing-aggr-name",aggrName)
        api.child_add_string("size",size)
        api.child_add_string("volume",volName)
        xo=self.execute(api)
        return xo.results_status()

    def volume_getoptions(self,volname):
        """" volume_getoptions. Retourne un dictionnaire avec ls options du volume.
       """
        api = NaElement("volume-options-list-info")
        api.child_add_string("volume",volname)
        xo=self.execute(api)
        listeOptions=xo.child_get("options").children_get()
        dictOptions={}
        for option in listeOptions:
            n=option.child_get_string("name")
            v=option.child_get_string("value")
            dictOptions[n]=v
        return dictOptions

    def ipspace_list_info(self):
        """
        :return
        """
        api= NaElement("ipspace-list-info")
        xo= self.execute(api)
        liste_ipspaces=xo.child_get("ipspaces").children_get()
        tableau=[]
        for ipspace in liste_ipspaces:
            nom=ipspace.child_get_string("name")
            liste_interfaces=ipspace.child_get("interfaces").children_get()
            for interface in liste_interfaces:
                nom_interface=interface.child_get_string("interface")
                vlan=nom_interface.split('-')[-1]
                if vlan.isnumeric():
                    vlan=int(vlan)
                else:
                    vlan=0
                tableau.append((nom,nom_interface,vlan))
                #print(("ipspace %s - intf %s %s")%(nom,nom_interface,vlan))
        return tableau


    def volume_setoption(self,volname,optionname,optionvalue):
        """"
            positionne les options sur un volume.
        :param volname : nom du volume
        :returns dict: dictoptions dictionnaire avec le nom de l'option en clé et sa valeur en valeur.
       """

        api = NaElement("volume-set-option")
        api.child_add_string("option-name", optionname)
        api.child_add_string("option-value", optionvalue)
        api.child_add_string("volume", volname)
        return self.execute(api).results_status()

    def volume_setoptions(self,volname,dicoptions):
        """"
            volume_setoptions. positionne les options sur un volume.
        :param volname : nom du volume
        :param dictoptions: dictionnaire avec le nom de l'option en clé et sa valeur en valeur.
        :raises NaError:
        """
        for k in dicoptions.keys():
            self.volume_setoption( volname , k , dicoptions[k] )
        return


    def volume_setsnapshot_reserve(self, volume_name, snapshot_reserve):
        """
           Mise en place du snapshot reserve sur un volume
        :param snapshot_reserve. pourcentage
        :param volume_name. nom du volume.
        :return:
        """
        api = NaElement( "snapshot-set-reserve")
        api.child_add_string("percentage", snapshot_reserve)
        api.child_add_string("volume",volume_name)
        return self.execute(api).results_status()

    def volume_setsnapshot_sched(self, volume_name,scheddico):
        """
          Schedule du snaphot sur un volume.
        :param volume_name:
        :param scheddico:   api.child_add_string("days","<days>")
                                           api.child_add_string("hours","<hours>")
                                           api.child_add_string("minutes","<minutes>")
                                           api.child_add_string("volume","<volume>")
                                           api.child_add_string("weeks","<weeks>")
                                           api.child_add_string("which-hours","<which-hours>")
                                           api.child_add_string("which-minutes","<which-minutes>")
        :return:
        """

        api = NaElement("snapshot-set-schedule")
        api.child_add_string("volume", volume_name)
        for k in scheddico.keys():
            api.child_add_string(k,scheddico[k])
        return self.execute(api).results_status()

    def volume_get_aggr(self,volume):
        """
            Récupère sur quel aggregat est le volume.
        :param volume:
        :return: aggr name
        :raise NaError:
        """
        dico=self.volume_listinfo(volume)
        return dico[volume]["containing-aggregate"]

    def volume_get_sisstate(self,volume_name):
        """
            Retourne "on" ou "off" suivant que la dedup est activée ou pas
        :param volume_name:
        :return: Retourne "on" ou "off" suivant que la dedup est activé ou pas
        :raise NaError:
        """
        if "/vol/" not in volume_name:
            volume_name="/vol/"+volume_name
        api = NaElement("sis-status")
        api.child_add_string("path",volume_name)
        api.child_add_string("verbose", "false")
        xo=self.execute(api)
        response=xo.child_get("sis-object").children_get()[0]
        state=response.child_get_string("state")
        return "on" if state in "Enabled" else "off"

    def volume_set_sis(self,volume_name,status):
        """
            Mise en place de la déduplication
        :param volume_name: nom du volume
        :param status: "on" ou "off"
        :return:
        :raise NaError:
        """
        api=None
        ret=None
        if "/vol/" not in volume_name:
            volume_name="/vol/"+volume_name

        if status in "on":
            api = NaElement("sis-enable")
        elif status in "off":
            api = NaElement("sis-disable")

        if api:
            api.child_add_string("path", volume_name)
            myerrno=None
            myex=None
            try:
                ret = self.execute(api).results_status()
            except NaError as e:
                if e.errno in "13001":pass #[errno 13001]= Operation is not enabled
                else: raise e
        return ret

    def volume_sis_sched(self, volume_name, sissched):
        """
            schedule de la deduplication
        :param volume_name: nom du volume
        :param sissched: schedule format jour@hour
        :return:
        :raise NaError:
        """
        if "/vol/" not in volume_name:
            volume_name="/vol/"+volume_name
        api = NaElement("sis-set-config")
        api.child_add_string("path",volume_name)
        api.child_add_string("schedule",sissched)
        ret=None
        try:
            ret=self.execute(api).results_status()
        except NaError as e:
            if e.errno in "13001":pass #[errno 13001]= Operation is not enabled
            else: raise e
        return ret

    def volume_size(self,volume, newsize=None):
        """
            Fixe la taille du volume. si le paramètre newsize est absent, la fonction renvoie la taille actuelle.
        :param volume: nom du volume
        :param newsize: taille du volume en Gb
        :return: renvoie la taille du volume (avec l'unite)
        :raise NaError:
        """
        api=NaElement("volume-size")
        api.child_add_string("volume",volume)
        if newsize:
            api.child_add_string("new-size",str(newsize))
        xo=self.execute(api)
        return xo.child_get_string("volume-size")


    def snapshot_list(self,volName):
        """
            Liste les snapshots
        :param volName: nom du volume
        :return dictionnaire:  dictSnap[name]  = {'state':state,'access-time':access-time,''busy":busy,"used_by':dependency}
        :raise NaError:
        """
        api=NaElement("snapshot-list-info")
        api.child_add_string("volume",volName)
        api.child_add_string("snapowners","true")
        xo=self.execute(api)
        listeSnapshots=xo.child_get("snapshots").children_get()
        dictSnap={}
        for snapshot in listeSnapshots:
            name=snapshot.child_get_string("name")
            accesstime=snapshot.child_get_string("access-time")
            busy=snapshot.child_get_string("busy")
            dependency=None
            if busy in "true":
                dependency=snapshot.child_get_string("dependency")

            dictSnap[name]={"access-time":accesstime,'busy':busy,"used_by":dependency}
        return dictSnap

    def snapshot_delete(self,volName,snapName):
        """
            delete d'un snapshot
        :param volName: nom du volume
        :param snapName: nom du snap
        :return: Exception NaError sir pb
        """
        api=NaElement("snapshot-delete")
        api.child_add_string("snapshot",snapName)
        api.child_add_string("volume",volName)
        return self.execute(api).results_status()

    def snapmirror_getvolume_status(self,volName):
        """
            retourne un dictionnaire avec les differents états snapmirror du volume
        :param volName:
        :return: diict={"is-source':true/false,'is-destination'-true/flase,'is-transfer-in-progress':true/false, 'is-transfer-broken':true/false}
        :raise NaError:
        """
        api=NaElement("snapmirror-get-volume-status")
        api.child_add_string("volume",volName)
        xo=self.execute(api)
        source=xo.child_get_string("is-source")
        destination=xo.child_get_string("is-destination")
        transfer=xo.child_get_string("is-transfer-in-progress")
        broken=xo.child_get_string("is-transfer-broken")
        return {"is-source":source, 'is-destination':destination,'is-transfer-in-progress':transfer, 'is-transfer-broken':broken}





    def snapvault_getsnapshotlist(self):
        """
            retourne un dictionnaire avec la corrspondance entre le nom du snapshot et sa source au niveau snapvault.
            utile pour détruire les  snapshot bloqués par une sauvegarde snapvault
        :return dict: dict[snapshot-name]=source-path-name
        :raise NaError:
        """
        api = NaElement("snapvault-primary-destinations-list-info")
        xo=self.execute(api)
        liste=xo.child_get("destinations").children_get()
        listeSource={}

        for i in liste:
            source=i.child_get_string("source-path")
            snap=i.child_get_string("source-snapshot")
            listeSource[snap]=source
        return listeSource

    def snapvault_primaryabort(self, systempath,target):
        """
            Abort de la relation snappvault sur le primaire
        :param systempath: nom de la qtree
        :param target: nom du système
        :return: naError en
        :raise NaError:
        """

        api = NaElement("snapvault-primary-abort-transfer")
        api.child_add_string("is-hard-abort","false")
        api.child_add_string("system-path",systempath)
        api.child_add_string("target-system",target)
        return self.execute(api).results_status()


    def write_file(self,fichier,data):
        """
              write_file. ecrit de données dans un fichier
             si le fichier existe, son contenu est remplacé.
        """
        api = NaElement("file-write-file")
        api.child_add_string("data",self.convert_to_hex(data))
        api.child_add_string("offset",0)
        api.child_add_string("overwrite","true")
        api.child_add_string("path",fichier)
        return self.execute(api)


    def read_file(self,fichier):
        """Lit un fichier"""
        api = NaElement("file-get-file-info")
        api.child_add_string("path",fichier)
        xo=self.execute(api)
        taille=(xo.child_get("file-info")).child_get_string("file-size")
        api1 = NaElement("file-read-file")
        api1.child_add_string("length",taille)
        api1.child_add_string("offset",0)
        api1.child_add_string("path",fichier)
        xo=self.execute(api1)
        return xo.child_get_string("data")

    def exportfs_list(self,vfiler):
        """
        Renvoie la liste des exports NFS
        :param vfiler: 
        :return:  
        tableau[]={"pathname':pathname,'actual-pathname':actualpathname,
                    'anon':anon,'nosuid':nosuid, 
                    'read-only':host,
                    'read-write':hosts,
                    'vfiler':vfiler }
        """
        self.set_vfiler_context(vfiler)
        api = NaElement("nfs-exportfs-list-rules")
        xo = self.execute(api)
        rulesInfos = xo.child_get("rules").children_get()
        resultats=[]
        for nfsexport in rulesInfos:
            pathname = nfsexport.child_get_string("pathname")
            actualpathname=nfsexport.child_get_string("actual-pathname")
            anon=nfsexport.child_get_string("anon")
            nosuid=nfsexport.child_get_string("nosuid")
            ro_allhosts=rw_allhosts=readonly=readwrite=None
            try:
                ro=nfsexport.child_get("read-only").children_get()
                try:
                    readonly=";".join([r.child_get_string("name") for r in ro])
                except TypeError:
                    pass
                try:
                    ro_allhosts=";".join([r.child_get_string("all-hosts") for r in ro])
                except TypeError:
                    pass
            except AttributeError:
                pass

            try:
                rw = nfsexport.child_get("read-write").children_get()
                try:
                    readwrite=";".join([r.child_get_string("name") for r in rw])
                except TypeError:
                    pass
                try:
                    rw_allhosts = ";".join([r.child_get_string("all-hosts") for r in rw])
                except TypeError:
                    pass
            except AttributeError:
                pass
            if ro_allhosts and readonly is None:
                readonly="ALL"
            if rw_allhosts and readwrite is None:
                readwrite = "ALL"

            resultats.append(
                {"pathname":pathname,"actualpathname":actualpathname,
                 "readonly": readonly, "readwrite": readwrite,
                 "anon":anon,"nosuid":nosuid,"vfiler":vfiler})
            #print(pathname,actualpathname,readonly,readwrite,anon,nosuid)
        self.unset_vfiler_context()
        return resultats

    def nfs4LockCount(self, vfiler):
        self.set_vfiler_context(vfiler)
        api = NaElement("lock-status-iter-start")
        api.child_add_string("protocol","nfsv4")
        xo = self.execute(api)
        record = xo.child_get_string("records")
        return record

    def convert_to_hex(self, someString):
        """Transforme une string en hexa"""
        return "".join("{:02x}".format(ord(a)) for a in someString)

    def convert_to_unit(self,nombre, p):
        """
            Divise un nombre par une puissance de 1024 et renvoie l'entier le plus proche
            Args :
            nombre (float or int). nombre a convertir.
            p (int). Puissance de 1024. Pour convertir des octets en Gb, p = 3
        """
        if nombre == 0: return 0
        return ceil(nombre/pow(1024,p))

    def useradmin_role_add(self,name,capabilities):
        """
            Créer un role sur un filer
        :param name: nom du role
        :param capabilities: tableau contenant la liste des capacité
        :return:
        :raise NaError:
        """
        api=NaElement("useradmin-role-add")
        xi = NaElement("useradmin-role")
        api.child_add(xi)

        xi1 = NaElement("useradmin-role-info")
        xi.child_add(xi1)


        xi2 = NaElement("allowed-capabilities")
        xi1.child_add(xi2)

        for cap in capabilities:
                xi3 = NaElement("useradmin-capability-info")
                xi2.child_add(xi3)
                xi3.child_add_string("name",cap)

        xi1.child_add_string("name",name)
        return self.execute(api).results_status()

    def useradmin_group_add(self, name, grouprole):
        """
            Créér un groupe
        :param name: nom du group
        :param grouprole: liste des roles auxquel ce groupe doit appartenir
        :return:
        :raise NaError:
        """
        api = NaElement("useradmin-group-add")
        xi_1 = NaElement("useradmin-group")
        api.child_add(xi_1)

        xi_1_1 = NaElement("useradmin-group-info")
        xi_1.child_add(xi_1_1)
        xi_1_1.child_add_string("name",name)
        xi_1_2 = NaElement("useradmin-roles")
        xi_1_1.child_add(xi_1_2)

        for role in grouprole:
            xi_1_3 = NaElement("useradmin-role-info")
            xi_1_2.child_add(xi_1_3)
            xi_1_3.child_add_string("name",role)
        return self.execute(api).results_status()

    def useradmin_user_add(self, username, userpassword, groupname):
        """
            Création user
        :param username:
        :param userpassword:
        :param groupname:
        :return:
        :raise NaEr
        """
        api=NaElement("useradmin-user-add")
        api.child_add_string("password",userpassword)
        xi = NaElement("useradmin-user")
        api.child_add(xi)
        xi1 = NaElement("useradmin-user-info")
        xi.child_add(xi1)
        xi1.child_add_string("name",username)
        xi2 = NaElement("useradmin-groups")
        xi1.child_add(xi2)
        xi3 = NaElement("useradmin-group-info")
        xi2.child_add(xi3)
        xi3.child_add_string("name", groupname)
        return self.execute(api).results_status()


class NaError(Exception):
    """class NaError(Exception)"""
    def __init__(self,message,errno,function):
        self.errno=errno
        self.message=message
        self.function=function
        Exception.__init__(self,message)

