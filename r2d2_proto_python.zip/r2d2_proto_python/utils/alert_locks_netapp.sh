#!/bin/sh
###########################################################
# Fichier       :                                         #
# Objet         : Alerte pour les locks excessifs         #
###########################################################


HISTO="/log/app/R2D2/locks"
DEST=DOP_INF_ISD_SSD_Alertes_Stockage@bpce-it.fr
MAXI=$1
rm $HISTO/alarme.rtf

for FIC in `ls $HISTO | tail -n7`
do
  egrep "Locks|lock" $HISTO/$FIC > $HISTO/temp.txt
  while read LIGNE
  do
    MOT1=`echo $LIGNE | cut -f1 -d" "`
    if [ $MOT1 = "Locks" ]
    then
      CTRL=`echo $LIGNE | cut -f4 -d" "`
      DATE=`echo $FIC | cut -f3 -d"_" | cut -f1 -d"."`
    else
      NBRE=`echo $LIGNE | awk -F" - " ' { print $2 }' | awk -F"lock" ' { print $1 }'`
      if [ $NBRE -gt $MAXI ]
      then
        VFILER=`echo $LIGNE | cut -f1 -d" "`
        echo "Le Vfiler" $VFILER "du controleur" $CTRL "a eu" $NBRE "locks le" $DATE >>$HISTO/alarme.rtf
      fi
    fi
  done < $HISTO/temp.txt
done 

rm $HISTO/temp.txt

if [ -f $HISTO/alarme.rtf ]
then
  tmail -se vtom_technique -to $DEST -smtp smtpauth.dom801.ibp -ac SVCEXHR00426 -pass Yby8VUMr#Xh6O8@bYADv -sub "Alerte locks NetApp excessifs" -msg "Ci-joint les Vfiler ayant eu plus de $MAXI locks durant les 7 derniers jours" -att "$HISTO/alarme.rtf"
else
  tmail -se vtom_technique -to $DEST -smtp smtpauth.dom801.ibp -ac SVCEXHR00426 -pass Yby8VUMr#Xh6O8@bYADv -sub "Controle des locks NetApp" -msg "Aucun depassement excessif du nombre de locks durant les 7 derniers jours"
fi
