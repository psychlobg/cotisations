#!/opt/UNS/VENV/VENV_CISCO/bin/python3

# -*- coding: utf-8 -*-
# Alimentation de la database


import os
import sys
import context
from datetime import datetime
###A remplacer par logger
from lib.utils.utils import perror
import argparse

def commandline_parser():
    p = argparse.ArgumentParser(description=os.path.basename( sys.argv[0] ))
    p.add_argument('-n','--nom',  type=str, help="Nom du filer",required=True)
    args=p.parse_args()
    return args

from config import Config

if __name__ == '__main__':
    myconfig = Config(os.path.abspath('..'))
    from lib.SevenModeApi import SevenModeApi, NaError
    from lib.AppLogger import AppLogger
    myLog=AppLogger(__file__,myconfig.log)
    from lib.db.Referentiel import Referentiel


    args=commandline_parser()
    fas=args.nom
    try:
        myFiler=SevenModeApi(fas, myconfig.batch_user, myconfig.batch_passwd)
        myFiler.setLogger(myLog)
        listeVfiler=myFiler.vfiler_list_info()
        for vfiler in listeVfiler:
            if listeVfiler[vfiler]["status"] == "running":
                 print("%s - %s lock(s)"%(vfiler,myFiler.nfs4LockCount(vfiler)))

    except NaError as e:
        d = datetime.now()
        perror(("%.2d%.2d-%.2d%.2d: [errno %s]= %s from %s")%(d.day,d.month,d.hour,d.minute,e.errno,e.message,e.function))
        sys.exit(1)

